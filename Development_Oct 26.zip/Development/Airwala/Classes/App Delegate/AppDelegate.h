//
//  AppDelegate.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AirwalaConstants.h"

@class ViewController;
@class AirwalaWebEngine;
@class AirwalaSearchTicketViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;
@property (strong, nonatomic) AirwalaWebEngine *webEngine;
@property (strong, nonatomic) AirwalaWebEngine *bookWebEngine;
@property (strong, nonatomic) AirwalaWebEngine *emailWebEngine;
@property (strong, nonatomic) UINavigationController *navController;
@property (strong, nonatomic) AirwalaSearchTicketViewController *searchTicketViewController;

@end