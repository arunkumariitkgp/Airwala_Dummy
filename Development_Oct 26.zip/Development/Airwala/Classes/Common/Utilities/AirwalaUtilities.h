//
//  AirwalaUtilities.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AirwalaUtilities : NSObject

void ModalAlert(NSString *inTitle, NSString *inMessage, NSString *inActionButton, NSString *inOtherButton, id inDelegate, SEL inSelector);

+ (CGSize)getTextSize:(NSString *)aText withFont:(UIFont *)aFont andConstrainedToSize:(CGSize)aSize;
+ (BOOL)isEmptyString:(NSString*)string;
+ (NSString *)formatDictionaryDetails:(NSDictionary *)dictinary;

@end
