//
//  UIViewController+ProgessSheet.h
//  Airwala
//
//  Created by startupsourcing on 04/09/12.
//
//

#import <UIKit/UIKit.h>

@interface UIViewController (ProgessSheet)

- (void)startCenterAndNonBlockBusyViewWithTitle:(NSString *)inTitle needUserInteraction:(BOOL)isEnabled;

- (void)startCenterAndNonBlockBusyViewWithTitle:(NSString *)inTitle needUserInteraction:(BOOL)isEnabled viewSize:(CGSize) size;

- (void)stopCenterAndNonBlockBusyViewWithTitle;

@end
