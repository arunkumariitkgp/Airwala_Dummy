//
//  AirwalaFlightTicketsCell.m
//  Airwala
//
//  Created by startupsourcing on 05/09/12.
//
//

#import "AirwalaFlightTicketsCell.h"

@interface AirwalaFlightTicketsCell ()

- (void)initializeUpJourneyViewOutlets;
- (void)initializeDownJourneyViewOutlets;

@end

@implementation AirwalaFlightTicketsCell

@synthesize upwardToLabel;
@synthesize returnToLabel;
@synthesize airlineImageView;
@synthesize airlineNameLabel;
@synthesize totalPriceLabel;
@synthesize upArrivalTimeLabel;
@synthesize upArrivalCodeLabel;
@synthesize upDepartureTimeLabel;
@synthesize upDepartureCodeLabel;
@synthesize staticTotalPriceLabel;
@synthesize downDepartureCodeLabel;
@synthesize downDepartureTimeLabel;
@synthesize downArrivalCodeLabel;
@synthesize downArrivalTimeLabel;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        airlineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(5, 5, 27, 23)];
        
        airlineNameLabel = [[UILabel alloc]initWithFrame:CGRectMake(35, 0, 125, 30)];
        airlineNameLabel.font = [UIFont systemFontOfSize:15.0];
        airlineNameLabel.adjustsFontSizeToFitWidth = YES;
        
        staticTotalPriceLabel = [[UILabel alloc]initWithFrame:CGRectMake(162, 0, 80, 30)];
        staticTotalPriceLabel.text = @"Total Price:";
        staticTotalPriceLabel.font = [UIFont systemFontOfSize:15.0];
        staticTotalPriceLabel.textAlignment = UITextAlignmentRight;
        
        totalPriceLabel = [[UILabel alloc]initWithFrame:CGRectMake(245, 0, 70, 30)];
        totalPriceLabel.font = [UIFont boldSystemFontOfSize:16.0];
        totalPriceLabel.textAlignment = UITextAlignmentCenter;
        
        [self initializeUpJourneyViewOutlets];
        
        if(![[[NSUserDefaults standardUserDefaults]objectForKey:kTripType] isEqualToString:kOneWay])
            [self initializeDownJourneyViewOutlets];
        [self addSubview:airlineImageView];
        [self addSubview:airlineNameLabel];
        [self addSubview:staticTotalPriceLabel];
        [self addSubview:totalPriceLabel];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

#pragma mark - Instance Methods

- (void)initializeUpJourneyViewOutlets
{
    upDepartureCodeLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 30, 30, 25)];
    upDepartureCodeLabel.font = [UIFont boldSystemFontOfSize:15.0];
    upDepartureCodeLabel.textAlignment = UITextAlignmentCenter;
    upDepartureCodeLabel.adjustsFontSizeToFitWidth = YES;
    upDepartureCodeLabel.backgroundColor = [UIColor clearColor];
    
    upDepartureTimeLabel = [[UILabel alloc]initWithFrame:CGRectMake(71, 30, 70, 25)];
    upDepartureTimeLabel.font = [UIFont systemFontOfSize:14.0];
    upDepartureTimeLabel.textAlignment = UITextAlignmentLeft;
    upDepartureTimeLabel.adjustsFontSizeToFitWidth = YES;
    upDepartureTimeLabel.backgroundColor = [UIColor clearColor];
    
    upwardToLabel = [[UILabel alloc]initWithFrame:CGRectMake(150, 30, 20, 25)];
    upwardToLabel.font = [UIFont systemFontOfSize:13.0];
    upwardToLabel.text = @"to";
    upwardToLabel.textAlignment = UITextAlignmentCenter;
    upwardToLabel.backgroundColor = [UIColor clearColor];
    
    upArrivalCodeLabel = [[UILabel alloc]initWithFrame:CGRectMake(201, 30, 30, 25)];
    upArrivalCodeLabel.font = [UIFont boldSystemFontOfSize:15.0];
    upArrivalCodeLabel.textAlignment = UITextAlignmentCenter;
    upArrivalCodeLabel.adjustsFontSizeToFitWidth = YES;
    upArrivalCodeLabel.backgroundColor = [UIColor clearColor];
    
    upArrivalTimeLabel = [[UILabel alloc]initWithFrame:CGRectMake(232, 30, 119, 25)];
    upArrivalTimeLabel.font = [UIFont systemFontOfSize:14.0];
    upArrivalTimeLabel.textAlignment = UITextAlignmentLeft;
    upArrivalTimeLabel.adjustsFontSizeToFitWidth = YES;
    upArrivalTimeLabel.backgroundColor = [UIColor clearColor];
    
    [self addSubview:upArrivalCodeLabel];
    [self addSubview:upArrivalTimeLabel];
    [self addSubview:upDepartureCodeLabel];
    [self addSubview:upDepartureTimeLabel];
    [self addSubview:upwardToLabel];
}

- (void)initializeDownJourneyViewOutlets
{
    downDepartureCodeLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 50, 30, 25)];
    downDepartureCodeLabel.font = [UIFont boldSystemFontOfSize:15.0];
    downDepartureCodeLabel.textAlignment = UITextAlignmentCenter;
    downDepartureCodeLabel.adjustsFontSizeToFitWidth = YES;
    downDepartureCodeLabel.backgroundColor = [UIColor clearColor];
    
    downDepartureTimeLabel = [[UILabel alloc]initWithFrame:CGRectMake(71, 50, 70, 25)];
    downDepartureTimeLabel.font = [UIFont systemFontOfSize:14.0];
    downDepartureTimeLabel.textAlignment = UITextAlignmentLeft;
    downDepartureTimeLabel.adjustsFontSizeToFitWidth = YES;
    downDepartureTimeLabel.backgroundColor = [UIColor clearColor];
    
    returnToLabel = [[UILabel alloc]initWithFrame:CGRectMake(150, 50, 20, 25)];
    returnToLabel.font = [UIFont systemFontOfSize:13.0];
    returnToLabel.text = @"to";
    returnToLabel.textAlignment = UITextAlignmentCenter;
    returnToLabel.backgroundColor = [UIColor clearColor];
    
    downArrivalCodeLabel = [[UILabel alloc]initWithFrame:CGRectMake(201, 50, 30, 25)];
    downArrivalCodeLabel.font = [UIFont boldSystemFontOfSize:15.0];
    downArrivalCodeLabel.textAlignment = UITextAlignmentCenter;
    downArrivalCodeLabel.adjustsFontSizeToFitWidth = YES;
    downArrivalCodeLabel.backgroundColor = [UIColor clearColor];
    
    downArrivalTimeLabel = [[UILabel alloc]initWithFrame:CGRectMake(232, 50, 119, 25)];
    downArrivalTimeLabel.font = [UIFont systemFontOfSize:14.0];
    downArrivalTimeLabel.textAlignment = UITextAlignmentLeft;
    downArrivalTimeLabel.adjustsFontSizeToFitWidth = YES;
    downArrivalTimeLabel.backgroundColor = [UIColor clearColor];
    
    [self addSubview:returnToLabel];
    [self addSubview:downArrivalCodeLabel];
    [self addSubview:downArrivalTimeLabel];
    [self addSubview:downDepartureCodeLabel];
    [self addSubview:downDepartureTimeLabel];
}

@end
