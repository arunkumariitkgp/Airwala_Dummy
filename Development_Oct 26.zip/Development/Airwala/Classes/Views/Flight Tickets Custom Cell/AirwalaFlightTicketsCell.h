//
//  AirwalaFlightTicketsCell.h
//  Airwala
//
//  Created by startupsourcing on 05/09/12.
//
//

#import <UIKit/UIKit.h>

@interface AirwalaFlightTicketsCell : UITableViewCell

#pragma mark - View Properties

@property (nonatomic, strong) UIImageView *airlineImageView;
@property (nonatomic, strong) UILabel *airlineNameLabel;
@property (nonatomic, strong) UILabel *totalPriceLabel;
@property (nonatomic, strong) UILabel *staticTotalPriceLabel;
@property (nonatomic, strong) UILabel *upwardToLabel;
@property (nonatomic, strong) UILabel *returnToLabel;

@property (nonatomic, strong) UILabel *upDepartureCodeLabel;
@property (nonatomic, strong) UILabel *upArrivalCodeLabel;
@property (nonatomic, strong) UILabel *upDepartureTimeLabel;
@property (nonatomic, strong) UILabel *upArrivalTimeLabel;

@property (nonatomic, strong) UILabel *downDepartureCodeLabel;
@property (nonatomic, strong) UILabel *downArrivalCodeLabel;
@property (nonatomic, strong) UILabel *downDepartureTimeLabel;
@property (nonatomic, strong) UILabel *downArrivalTimeLabel;

@end
