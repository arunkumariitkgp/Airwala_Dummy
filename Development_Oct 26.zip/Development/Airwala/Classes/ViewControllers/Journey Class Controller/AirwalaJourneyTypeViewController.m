//
//  AirwalaJourneyTypeViewController.m
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 03/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AirwalaJourneyTypeViewController.h"

@interface AirwalaJourneyTypeViewController ()

@end

@implementation AirwalaJourneyTypeViewController

@synthesize journeyTypeDelegate;
@synthesize classListTableView;
@synthesize textField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        mJourneyTypeArray = [[NSArray alloc]initWithObjects:@"E - Economy", @"B - Bussiness", @"F - First Class", @"A - All", nil];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [mJourneyTypeArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text = [mJourneyTypeArray objectAtIndex:indexPath.row];
    cell.textLabel.font = [UIFont systemFontOfSize:16.0];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(journeyTypeDelegate && [journeyTypeDelegate respondsToSelector:@selector(journeyTypeSelected:andTextField:)])
    {
        [journeyTypeDelegate journeyTypeSelected:[mJourneyTypeArray objectAtIndex:indexPath.row] andTextField:self.textField];
    }
    
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark - Instance Methods

- (NSString *)formatSelectedJourneyType:(NSString *)journeyType
{
    NSArray *arr = [journeyType componentsSeparatedByString:@" - "];
    return [arr objectAtIndex:0];
}

- (IBAction)cancel:(id)sender
{
    if(journeyTypeDelegate && [journeyTypeDelegate respondsToSelector:@selector(cancelSelectingAirport)])
    {
        [journeyTypeDelegate cancelSelectingAirport];
    }
    
    [self dismissModalViewControllerAnimated:YES];
}

@end
