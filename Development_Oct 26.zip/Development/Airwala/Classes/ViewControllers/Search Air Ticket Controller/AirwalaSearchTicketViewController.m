//
//  AirwalaSearchTicketViewController.m
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"
#import "AirwalaWebEngine.h"
#import "UIViewController+MHSemiModal.h"
#import "AirwalaAirportListViewController.h"
#import "AirwalaJourneyTypeViewController.h"
#import "AirwalaSearchTicketViewController.h"
#import "AirwalaFlightTicketsViewController.h"


@interface AirwalaSearchTicketViewController ()

- (void)resigningFirstResponders;
- (NSString *)formatSelectedJourneyType:(NSString *)journeyType;
- (void)animateTextFieldWithContentOffset:(CGPoint)contentOffset andContentSize:(CGSize)contentSize;
- (void)modifyTextFieldFrames:(CGRect)fromRect
                      toField:(CGRect)toRect
                     depField:(CGRect)depRect
                     arrField:(CGRect)arrRect
                   adultField:(CGRect)adultRect
                   childField:(CGRect)childRect
                andClassField:(CGRect)classRect
              alsoToIndicator:(CGRect)toIndicatorRect
             andFromIndicator:(CGRect)fromIndicatorRect;
- (NSString *)airportNameForLocationAfterSorting:(NSArray *)listArray;
- (NSString *)formatSelectedAirport:(NSString *)selectedAirport;

@end

@implementation AirwalaSearchTicketViewController

@synthesize datePickerViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"Airwala";
        mSegmentControlIndex = 1;
//        currentCityName = [[NSString alloc]init];
//        currentCountryName = [[NSString alloc]init];
    }
    return self;
}

#pragma mark - View Hierarchy

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    typeSegmentControl.selectedSegmentIndex = 0;
    [typeSegmentControl addTarget:self action:@selector(segmentedControlTapped:) forControlEvents:UIControlEventValueChanged];
    firstPageScrollView.delegate = self;
    secondPageScrollView.delegate = self;
    thirdPageScrollView.delegate = self;
    [fromField addTarget:self action:@selector(searchForText:) forControlEvents:UIControlEventEditingChanged];
    [toField addTarget:self action:@selector(searchForText:) forControlEvents:UIControlEventEditingChanged];
    
    [[AirwalaAirportListManager sharedInstance]setAirportListDelegate:self];
    [[AirwalaSearchFlightsManager sharedInstance]setSearchFlightDelegate:self];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:kRoundTrip forKey:kTripType];
    [defaults synchronize];
    
    selectedDate = [[NSDate alloc]init];
    selectedDate = [NSDate date];
//    [self startCenterAndNonBlockBusyViewWithTitle:@"Searching Current Location..." needUserInteraction:NO];
//    locationManager = [[CLLocationManager alloc]init];
//    locationManager.delegate = self;
//    [locationManager startUpdatingLocation];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Segmented Control Method

- (void)segmentedControlTapped:(id)sender
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if([sender selectedSegmentIndex] == 0)
    {
        [self resigningFirstResponders];
        mSegmentControlIndex = 1;
        [defaults setObject:kRoundTrip forKey:kTripType];
        [defaults synchronize];
        [UIView beginAnimations:@"First Page" context:nil];
        detailView.frame = CGRectMake(0, 39, 960, 265);
        
        [self modifyTextFieldFrames:CGRectMake(23, fromField.frame.origin.y, fromField.frame.size.width, fromField.frame.size.height)
                            toField:CGRectMake(23, toField.frame.origin.y, toField.frame.size.width, toField.frame.size.height)
                           depField:CGRectMake(23, departureDateField.frame.origin.y, 132, departureDateField.frame.size.height)
                           arrField:CGRectMake(164, returnDateField.frame.origin.y, returnDateField.frame.size.width, returnDateField.frame.size.height)
                         adultField:CGRectMake(23, adultField.frame.origin.y, adultField.frame.size.width, adultField.frame.size.height)
                         childField:CGRectMake(164, childrenField.frame.origin.y, childrenField.frame.size.width, childrenField.frame.size.height)
                      andClassField:CGRectMake(23, classField.frame.origin.y, classField.frame.size.width, classField.frame.size.height)
                    alsoToIndicator:CGRectMake(270, toActivityIndicator.frame.origin.y, toActivityIndicator.frame.size.width, toActivityIndicator.frame.size.height)
                   andFromIndicator:CGRectMake(270, fromActivityIndicator.frame.origin.y, fromActivityIndicator.frame.size.width, fromActivityIndicator.frame.size.height)];
        
        [UIView commitAnimations];
    }
    else if([sender selectedSegmentIndex] == 1)
    {
        [self resigningFirstResponders];
        mSegmentControlIndex = 2;
        [defaults setObject:kOneWay forKey:kTripType];
        [defaults synchronize];
        [UIView beginAnimations:@"Second Page" context:nil];
        detailView.frame = CGRectMake(-320, 39, 960, 265);
        
        [self modifyTextFieldFrames:CGRectMake(343, fromField.frame.origin.y, fromField.frame.size.width, fromField.frame.size.height)
                            toField:CGRectMake(343, toField.frame.origin.y, toField.frame.size.width, toField.frame.size.height)
                           depField:CGRectMake(343, departureDateField.frame.origin.y, 273, departureDateField.frame.size.height)
                           arrField:CGRectMake(164, returnDateField.frame.origin.y, returnDateField.frame.size.width, returnDateField.frame.size.height)
                         adultField:CGRectMake(343, adultField.frame.origin.y, adultField.frame.size.width, adultField.frame.size.height)
                         childField:CGRectMake(484, childrenField.frame.origin.y, childrenField.frame.size.width, childrenField.frame.size.height)
                      andClassField:CGRectMake(343, classField.frame.origin.y, classField.frame.size.width, classField.frame.size.height)
                    alsoToIndicator:CGRectMake(590, toActivityIndicator.frame.origin.y, toActivityIndicator.frame.size.width, toActivityIndicator.frame.size.height)
                   andFromIndicator:CGRectMake(590, fromActivityIndicator.frame.origin.y, fromActivityIndicator.frame.size.width, fromActivityIndicator.frame.size.height)];
        
        [UIView commitAnimations];
    }
    else 
    {
//        [self resigningFirstResponders];
//        mSegmentControlIndex = 3;
//        [defaults setObject:@"multiple" forKey:kTripType];
//        [defaults synchronize];
//        [UIView beginAnimations:@"Third Page" context:nil];
//        detailView.frame = CGRectMake(-640, 39, 960, 265);
//        
//        [self modifyTextFieldFrames:CGRectMake(665, fromField.frame.origin.y, fromField.frame.size.width, fromField.frame.size.height)
//                            toField:CGRectMake(665, toField.frame.origin.y, toField.frame.size.width, toField.frame.size.height)
//                           depField:CGRectMake(665, departureDateField.frame.origin.y, 132, departureDateField.frame.size.height)
//                           arrField:CGRectMake(806, returnDateField.frame.origin.y, returnDateField.frame.size.width, returnDateField.frame.size.height)
//                         adultField:CGRectMake(665, adultField.frame.origin.y, adultField.frame.size.width, adultField.frame.size.height)
//                         childField:CGRectMake(806, childrenField.frame.origin.y, childrenField.frame.size.width, childrenField.frame.size.height)
//                      andClassField:CGRectMake(665, classField.frame.origin.y, classField.frame.size.width, classField.frame.size.height)
//                    alsoToIndicator:CGRectMake(23, toActivityIndicator.frame.origin.y, toActivityIndicator.frame.size.width, toActivityIndicator.frame.size.height)
//                   andFromIndicator:CGRectMake(23, fromActivityIndicator.frame.origin.y, fromActivityIndicator.frame.size.width, fromActivityIndicator.frame.size.height)];
//        
//        [UIView commitAnimations];
    }
}

#pragma mark - TextField Delegate Methods

- (void)searchForText:(UITextField *)textField 
{
    if([[textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] == 3)
    {
        if(![AIRWALA_APP_DELEGATE.webEngine isReachable])
        {
            ModalAlert(@"No internet", @"Your device is not connected to the internet! Please connect and try again", @"OK", nil, nil, nil);
            return;
        }
        if(textField == fromField)
            [fromActivityIndicator startAnimating];
        else
            [toActivityIndicator startAnimating];
        [[AirwalaAirportListManager sharedInstance]getAirportsListWithTextField:textField];
    }
}

- (void)displayClassCategoryList:(UITextField *)textField
{
    AirwalaJourneyTypeViewController *journeyTypeController = [[AirwalaJourneyTypeViewController alloc]initWithNibName:@"AirwalaJourneyTypeViewController" bundle:nil];
    journeyTypeController.journeyTypeDelegate = self;
    journeyTypeController.textField = textField;
    [journeyTypeController.classListTableView reloadData];
    [self presentModalViewController:journeyTypeController animated:YES];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    BOOL shouldBeginEditing;
    
    if(textField == departureDateField)
    {
        shouldBeginEditing = NO;
        [self resigningFirstResponders];
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 101.0) andContentSize:CGSizeMake(318.0, 590.0)];
        selectedDate = [NSDate dateWithTimeIntervalSinceNow:kDateAfterTwoDays];
        
        datePickerViewController = [[AirwalaDatePickerViewController alloc] initWithNibName:@"AirwalaDatePickerViewController" bundle:nil];
        datePickerViewController.canShowPickerView = NO;
        datePickerViewController.defaultDate = selectedDate;
        datePickerViewController.delegate = self;
        datePickerViewController.selectedTextField = textField;
        
        [self mh_presentSemiModalViewController:datePickerViewController animated:YES];
    }
    else if(textField == returnDateField)
    {
        shouldBeginEditing = NO;
        [self resigningFirstResponders];
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 101.0) andContentSize:CGSizeMake(318.0, 590.0)];
        
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
        [dateFormat setDateFormat:@"MM/dd/yyyy"];
        if (![departureDateField.text isEqualToString:@""]) {
            selectedDate = [dateFormat dateFromString:departureDateField.text];
        }
        
        datePickerViewController = [[AirwalaDatePickerViewController alloc] initWithNibName:@"AirwalaDatePickerViewController" bundle:nil];
        datePickerViewController.canShowPickerView = NO;
        datePickerViewController.defaultDate = [NSDate dateWithTimeInterval:kDateAfterOneMonth sinceDate:selectedDate];
        datePickerViewController.delegate = self;
        datePickerViewController.selectedTextField = textField;
        
        [self mh_presentSemiModalViewController:datePickerViewController animated:YES];

    }
    else if(textField == classField)
    {
        shouldBeginEditing = NO;
        [self resigningFirstResponders];
        AirwalaJourneyTypeViewController *journeyTypeController = [[AirwalaJourneyTypeViewController alloc]initWithNibName:@"AirwalaJourneyTypeViewController" bundle:nil];
        journeyTypeController.journeyTypeDelegate = self;
        journeyTypeController.textField = textField;
        [journeyTypeController.classListTableView reloadData];
        [self presentModalViewController:journeyTypeController animated:YES];
    }
    else{
        shouldBeginEditing = YES;
    }
    return shouldBeginEditing;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if(textField == adultField || textField == childrenField || textField == classField)
    {
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 101.0) andContentSize:CGSizeMake(318.0, 590.0)];
    }
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    // may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - Airport List Manager Delegate

- (void)didAirportListDataUpdated:(NSMutableDictionary *)updatedDict andTextField:(UITextField *)textField
{
    if(textField == fromField)
        [fromActivityIndicator stopAnimating];
    else 
        [toActivityIndicator stopAnimating];
    
    if([[updatedDict valueForKeyPath:@"airportListResponse.airports"] count])
    {
        AirwalaAirportListViewController *airportsListController = [[AirwalaAirportListViewController alloc]initWithNibName:@"AirwalaAirportListViewController" bundle:nil];
        airportsListController.selectedAirportDelegate = self;
        airportsListController.textField = textField;
        airportsListController.airportsListArray = [updatedDict valueForKeyPath:@"airportListResponse.airports"];
        [airportsListController.airportsListTableView reloadData];
        [self presentModalViewController:airportsListController animated:YES];
    }
    else
    {
        ModalAlert(@"Sorry", @"There are no airports for given option", @"OK", nil, nil, nil);
    }
}

- (void)selectedAirportName:(NSString *)airportName andTextField:(UITextField *)textField
{
    [textField setText:airportName];
}

- (void)journeyTypeSelected:(NSString *)journeyType andTextField:(UITextField *)textField
{
    [textField setText:journeyType];
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

- (void)cancelSelectingAirport
{
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

- (void)airportListForLocationManager:(NSMutableDictionary *)updatedDict
{
    [self stopCenterAndNonBlockBusyViewWithTitle];
    if([[updatedDict valueForKeyPath:@"airportListResponse.airports"] count])
    {
        NSArray *airportListArray = [[NSArray alloc]init];
        airportListArray = [updatedDict valueForKeyPath:@"airportListResponse.airports"];
        fromField.text = [self formatSelectedAirport:[self airportNameForLocationAfterSorting:airportListArray]];
    }
    else
        fromField.text = nil;
}

- (void)airportListOperationFailed:(UITextField *)textField
{   
    if(textField == fromField)
        [fromActivityIndicator stopAnimating];
    else
        [toActivityIndicator stopAnimating];
    ModalAlert(@"Operation Failed", @"Please try again", @"OK", nil, nil, nil);
}

#pragma mark - Flights List Manager Delegate

- (void)updateFlightList:(NSMutableDictionary *)flightListDict
{
    [self stopCenterAndNonBlockBusyViewWithTitle];
    if([flightListDict objectForKey:@"hop2WsError"])
    {
        NSArray *arr = [flightListDict valueForKeyPath:@"hop2WsError.errors.message"];
        ModalAlert(@"Wrong Details", [arr objectAtIndex:0], @"OK", nil, nil, nil);
    }
    else
    {
        AirwalaFlightTicketsViewController *flightTicketsController = [[AirwalaFlightTicketsViewController alloc]initWithNibName:@"AirwalaFlightTicketsViewController" bundle:nil];
        flightTicketsController.flightTicketsDict = flightListDict;
        flightTicketsController.title = @"Flights List";
        [self.navigationController pushViewController:flightTicketsController animated:YES];
    }
}

- (void)flightListOperationFailed
{
    [self stopCenterAndNonBlockBusyViewWithTitle];
    ModalAlert(@"Operation Failed", @"Please try again", @"OK", nil, nil, nil);
}

#pragma mark - AirwalaDatePickerViewController delegate

- (void)setDate:(NSDate *)pickerDate andTextField:(UITextField *)textField
{
    if (pickerDate == nil)
    {
        [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
        return;
    }
    
    NSDateFormatter *displayDateFormatter = [[NSDateFormatter alloc] init];
    [displayDateFormatter setDateFormat:@"MM/dd/yyyy"];
    NSString *displayDateStr = [displayDateFormatter stringFromDate:pickerDate];
    textField.text = displayDateStr;
    
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

#pragma mark - Action Methods

- (IBAction)findFlights:(id)sender
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setInteger:[adultField.text integerValue]
                  forKey:kAdultCount];
    [defaults setInteger:[childrenField.text integerValue]
                  forKey:kChildCount];
    [defaults synchronize];
    if(![AIRWALA_APP_DELEGATE.webEngine isReachable])
    {
        ModalAlert(@"No internet", @"Your device is not connected to the internet! Please connect and try again", @"OK", nil, nil, nil);
        return;
    }
    [self startCenterAndNonBlockBusyViewWithTitle:@"Loading..." needUserInteraction:NO];

    switch (mSegmentControlIndex) {
        case 1:
            [[AirwalaSearchFlightsManager sharedInstance]findFlightsListForRoundTripWithSourceAirport:fromField.text
                                                                                   destinationAirport:toField.text
                                                                                        departureDate:departureDateField.text
                                                                                           returnDate:returnDateField.text
                                                                                       numberOfAdults:[adultField.text intValue]
                                                                                     numberOfChildren:[childrenField.text intValue]
                                                                                         andClassType:[self formatSelectedJourneyType:classField.text]];
            break;
        case 2:
            [[AirwalaSearchFlightsManager sharedInstance]findFlightsListForOneWayWithSourceAirport:fromField.text
                                                                                destinationAirport:toField.text
                                                                                     departureDate:departureDateField.text
                                                                                    numberOfAdults:[adultField.text intValue]
                                                                                  numberOfChildren:[childrenField.text intValue]
                                                                                      andClassType:[self formatSelectedJourneyType:classField.text]];
            break;
        default:
            break;
    }
}

#pragma mark - Helper Methods

- (void)resigningFirstResponders
{
    [toField resignFirstResponder];
    [fromField resignFirstResponder];
    [adultField resignFirstResponder];
    [childrenField resignFirstResponder];
    [classField resignFirstResponder];
}

- (NSString *)formatSelectedJourneyType:(NSString *)journeyType
{
    NSArray *arr = [journeyType componentsSeparatedByString:@" - "];
    return [arr objectAtIndex:0];
}

- (void)animateTextFieldWithContentOffset:(CGPoint)contentOffset andContentSize:(CGSize)contentSize
{
    [UIView beginAnimations:@"moveUpOrDown" context:nil];
	firstPageScrollView.contentSize = contentSize;
	firstPageScrollView.contentOffset = contentOffset;
	[UIView commitAnimations];
}

- (void)modifyTextFieldFrames:(CGRect)fromRect
                      toField:(CGRect)toRect
                     depField:(CGRect)depRect
                     arrField:(CGRect)arrRect
                   adultField:(CGRect)adultRect
                   childField:(CGRect)childRect
                andClassField:(CGRect)classRect
              alsoToIndicator:(CGRect)toIndicatorRect
             andFromIndicator:(CGRect)fromIndicatorRect
{
    fromField.frame = fromRect;
    toField.frame = toRect;
    departureDateField.frame = depRect;
    returnDateField.frame = arrRect;
    adultField.frame = adultRect;
    childrenField.frame = childRect;
    classField.frame = classRect;
    toActivityIndicator.frame = toIndicatorRect;
    fromActivityIndicator.frame = fromIndicatorRect;
}

- (NSString *)airportNameForLocationAfterSorting:(NSArray *)listArray
{
    NSString *locatedAirport = [[NSString alloc]init];
    for (int index = 0; index < [listArray count]; index ++)
    {
        NSString *mainStr = [[[listArray objectAtIndex:index]componentsSeparatedByString:@" - "] objectAtIndex:1];
        NSArray *arr = [mainStr componentsSeparatedByString:@", "];
        if ([[arr objectAtIndex:0] isEqualToString:currentCityName] && [[arr objectAtIndex:1] isEqualToString:currentCountryName]) {
            locatedAirport = [listArray objectAtIndex:index];
        }
    }
    return locatedAirport;
}

- (NSString *)formatSelectedAirport:(NSString *)selectedAirport
{
    NSArray *arr = [selectedAirport componentsSeparatedByString:@"("];
    arr = [[arr objectAtIndex:1]componentsSeparatedByString:@")"];
    return [arr objectAtIndex:0];
}

#pragma mark - ScrollView Delegate

- (void)scrollViewTouched
{
    [toField resignFirstResponder];
    [fromField resignFirstResponder];
    [adultField resignFirstResponder];
    [childrenField resignFirstResponder];
    [classField resignFirstResponder];	
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

#pragma mark - CLLocationManager and MKReverseGeoCoder Delegates

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    [locationManager stopUpdatingLocation];
    CLLocationCoordinate2D location;
    location.latitude = 30.2955;
    location.longitude = -97.8133;
    reverseGeocoder =
    [[MKReverseGeocoder alloc] initWithCoordinate:newLocation.coordinate];
    reverseGeocoder.delegate = self;
    [reverseGeocoder start];
}

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFailWithError:(NSError *)error
{
    NSString *errorMessage = [error localizedDescription];
    [self stopCenterAndNonBlockBusyViewWithTitle];
    ModalAlert(@"Cannot obtain address.", errorMessage, @"OK", nil, nil, nil);
}

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFindPlacemark:(MKPlacemark *)placemark
{
    DLog(@"place Mark +++++%@",placemark.addressDictionary);
    currentCityName = [placemark.addressDictionary objectForKey:@"City"];
    currentCountryName = [placemark.addressDictionary objectForKey:@"Country"];
    [[AirwalaAirportListManager sharedInstance] getAirportsListWithString:currentCityName];//[currentCityName substringToIndex:3]];
}

@end
