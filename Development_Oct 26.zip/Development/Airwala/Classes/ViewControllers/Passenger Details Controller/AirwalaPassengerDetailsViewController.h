//
//  AirwalaPassengerDetailsViewController.h
//  Airwala
//
//  Created by startupsourcing on 24/09/12.
//
//

#import <UIKit/UIKit.h>
#import "AirwalaTextField.h"
#import "AirwalaDatePickerViewController.h"

@interface AirwalaPassengerDetailsViewController : UIViewController <AirwalaDatePickerViewControllerDelegate, UITextFieldDelegate, UIActionSheetDelegate>
{
    NSInteger mCount;
    NSInteger mAdultCount;
    NSArray *mRowNamesArray;
    NSInteger mChildrenCount;
    NSArray *mPassengerKeysArray;
    NSArray *mPlaceHolderNamesArray;
    NSArray *mTextFieldReferenceArray;
    NSMutableArray *mSectionNamesArray;
    NSMutableDictionary *mTextFieldContentDict;
    
    AirwalaTextField *mMiddleNameField;
    AirwalaTextField *mFirstNameField;
    AirwalaTextField *mLastNameField;
    AirwalaTextField *mGenderField;
    AirwalaTextField *mTypeField;
    AirwalaTextField *mDobField;
}

@property (nonatomic, strong) IBOutlet UITableView *passengerDetailsTableView;
@property (nonatomic, strong) IBOutlet UIButton *nextPassengerButton;
@property (nonatomic, strong) IBOutlet UIButton *previousPassengerButton;
@property (nonatomic, strong) AirwalaDatePickerViewController *datePickerViewController;

- (IBAction)nextPassenger:(id)sender;
- (IBAction)previousPassenger:(id)sender;

@end
