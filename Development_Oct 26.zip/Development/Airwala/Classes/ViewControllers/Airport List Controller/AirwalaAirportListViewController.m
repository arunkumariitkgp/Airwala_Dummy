//
//  AirwalaAirportListViewController.m
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 31/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AirwalaAirportListViewController.h"

@interface AirwalaAirportListViewController ()

@end

@implementation AirwalaAirportListViewController

@synthesize textField;
@synthesize airportsListTableView;
@synthesize selectedAirportDelegate;
@synthesize airportsListArray = mAirportsListArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Airports List";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [mAirportsListArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text = [mAirportsListArray objectAtIndex:indexPath.row];
    cell.textLabel.font = [UIFont systemFontOfSize:14.0];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(selectedAirportDelegate && [selectedAirportDelegate respondsToSelector:@selector(selectedAirportName:andTextField:)])
    {
        [selectedAirportDelegate selectedAirportName:[self formatSelectedAirport:[mAirportsListArray objectAtIndex:indexPath.row]] andTextField:self.textField];
    }
    
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark - Action Methods

- (IBAction)cancel:(id)sender
{
    [self dismissModalViewControllerAnimated:YES];
}

- (NSString *)formatSelectedAirport:(NSString *)selectedAirport
{
    NSArray *arr = [selectedAirport componentsSeparatedByString:@"("];
    arr = [[arr objectAtIndex:1]componentsSeparatedByString:@")"];
    return [arr objectAtIndex:0];
}

@end
