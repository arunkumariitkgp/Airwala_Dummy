//
//  AirwalaFlightTicketDetailViewController.m
//  Airwala
//
//  Created by startupsourcing on 07/09/12.
//
//

#import "AirwalaTicketDetailsCell.h"
#import "AirwalaPassengerDetailsViewController.h"
#import "AirwalaFlightTicketDetailViewController.h"

@interface AirwalaFlightTicketDetailViewController ()

- (void)customInitialization;
- (void)priceDetailsWithoutChildren:(AirwalaTicketDetailsCell *)cell
                       withIndexPath:(NSIndexPath *)indexPath;
- (void)priceDetailsWithAdultsAndChildren:(AirwalaTicketDetailsCell *)cell
                             withIndexPath:(NSIndexPath *)indexPath;
- (NSString *)calculateTotalTax;
- (NSString *)formatRoutingDetails:(NSDictionary *)routingDict;
- (NSString *)manageTripDetails:(NSArray *)tripArray;

@end

@implementation AirwalaFlightTicketDetailViewController

@synthesize airlineImage;
@synthesize airlineNameString;
@synthesize selectedRoutingDetailsDict;

@synthesize upwardFlightNumberArray;
@synthesize upwardAircraftCodeArray;
@synthesize upwardDepartureCodeArray;
@synthesize upwardArrivalCodeArray;
@synthesize upwardDepartureTimeArray;
@synthesize upwardArrivalTimeArray;

@synthesize returnFlightNumberArray;
@synthesize returnAircraftCodeArray;
@synthesize returnDepartureCodeArray;
@synthesize returnArrivalCodeArray;
@synthesize returnDepartureTimeArray;
@synthesize returnArrivalTimeArray;

@synthesize adultBasePriceString;
@synthesize childBasePriceString;
@synthesize adultTaxString;
@synthesize childTaxString;
@synthesize totalPriceString;

#pragma mark - Initializing View 

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        [self customInitialization];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"Book"
//                                                                             style:UIBarButtonItemStyleBordered
//                                                                            target:self
//                                                                            action:@selector(bookTicket:)];
//    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back"
//                                                                             style:UIBarButtonItemStyleBordered
//                                                                            target:nil
//                                                                            action:nil];
    UIImage *backButtonImageNormal = [UIImage imageNamed:@"topbar_button_back"];
    UIImage *backButtonImagePressed = [UIImage imageNamed:@"topbar_button_back_pressed"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:backButtonImageNormal forState:UIControlStateNormal];
    [backButton setImage:backButtonImagePressed forState:UIControlStateSelected];
    
    backButton.frame = CGRectMake(0, 0, backButtonImageNormal.size.width, backButtonImageNormal.size.height);
    
    [backButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = customBarItem;
    
    UIImage *buttonImageNormal = [UIImage imageNamed:@"topbar_button"];
    UIImage *buttonImagePressed = [UIImage imageNamed:@"topbar_button_pressed"];
    UIButton *bookButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bookButton setBackgroundImage:buttonImageNormal forState:UIControlStateNormal];
    [bookButton setBackgroundImage:buttonImagePressed forState:UIControlStateSelected];
    [bookButton setTitle:@"Book" forState:UIControlStateNormal];
    [bookButton setTitle:@"Book" forState:UIControlStateSelected];
    bookButton.titleLabel.font = [UIFont boldSystemFontOfSize:13.0];
    
    bookButton.frame = CGRectMake(0, 0, buttonImageNormal.size.width, buttonImageNormal.size.height);
    
    [bookButton addTarget:self action:@selector(bookTicket:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBar = [[UIBarButtonItem alloc] initWithCustomView:bookButton];
    self.navigationItem.rightBarButtonItem = customBar;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    mAdultCount = [defaults integerForKey:kAdultCount];
    mChildrenCount = [defaults integerForKey:kChildCount];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [mTableHeaderNamesArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger count;
    
    if(![[[NSUserDefaults standardUserDefaults]objectForKey:kTripType] isEqualToString:kOneWay])
    {
        if(section == 0)
        {
            count = [upwardDepartureCodeArray count];
        }
        else if(section == 1)
        {
            count = [returnDepartureCodeArray count];
        }
        else
        {
            if(mChildrenCount == 0)
                count = [mOnlyAdultsArray count];
            else
                count = [mPriceCategoryArray count];
        }
    }
    else
    {
        if(section == 0)
        {
            count = [upwardDepartureCodeArray count];
        }
        else if(section == 1)
        {
            if(mChildrenCount == 0)
                count = [mOnlyAdultsArray count];
            else
                count = [mPriceCategoryArray count];
        }
    }
    return count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height;
    if(![[[NSUserDefaults standardUserDefaults]objectForKey:kTripType] isEqualToString:kOneWay])
    {
        if(indexPath.section == 0 || indexPath.section == 1)
        {
            height = 55.0;
        }
        else
        {
            height = 35;
        }
    }
    else
    {
        if(indexPath.section == 0)
        {
            height = 55.0;
        }
        else if(indexPath.section == 1)
        {
            height = 35;
        }
    }
    return height;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"GeneralCell";
    static NSString *CellId = @"LastSection";
    
    AirwalaTicketDetailsCell *generalCell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    UITableViewCell *tempCell;
    
    if(generalCell == nil)
    {
        generalCell = [[AirwalaTicketDetailsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if(indexPath.section == 0)
    {
        generalCell.airlineImageView.image = airlineImage;
        generalCell.airlineDetailLabel.text = [NSString stringWithFormat:@"%@  %@  %@",airlineNameString,[upwardFlightNumberArray objectAtIndex:indexPath.row],[upwardAircraftCodeArray objectAtIndex:indexPath.row]];
        generalCell.airportCodeDetails.text = [NSString stringWithFormat:@"%@(%@)       to       %@(%@)",[upwardDepartureCodeArray objectAtIndex:indexPath.row],[[[upwardDepartureTimeArray objectAtIndex:indexPath.row] componentsSeparatedByString:@" "] objectAtIndex:1],[upwardArrivalCodeArray objectAtIndex:indexPath.row],[[[upwardArrivalTimeArray objectAtIndex:indexPath.row] componentsSeparatedByString:@" "] objectAtIndex:1]];
        tempCell = generalCell;
    }
    
    if(![[[NSUserDefaults standardUserDefaults]objectForKey:kTripType] isEqualToString:kOneWay])
    {
        if(indexPath.section == 1)
        {
            generalCell.airlineImageView.image = airlineImage;
            generalCell.airlineDetailLabel.text = [NSString stringWithFormat:@"%@  %@  %@",airlineNameString,[returnFlightNumberArray objectAtIndex:indexPath.row],[returnAircraftCodeArray objectAtIndex:indexPath.row]];
            generalCell.airportCodeDetails.text = [NSString stringWithFormat:@"%@(%@)       to       %@(%@)",[returnDepartureCodeArray objectAtIndex:indexPath.row],[[[returnDepartureTimeArray objectAtIndex:indexPath.row] componentsSeparatedByString:@" "] objectAtIndex:1],[returnArrivalCodeArray objectAtIndex:indexPath.row],[[[returnArrivalTimeArray objectAtIndex:indexPath.row] componentsSeparatedByString:@" "] objectAtIndex:1]];
            tempCell = generalCell;
        }
        
        if(indexPath.section == 2)
        {
            AirwalaTicketDetailsCell *sectionCell = [tableView dequeueReusableCellWithIdentifier:CellId];
            
            if(sectionCell == nil)
            {
                sectionCell = [[AirwalaTicketDetailsCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellId];
                sectionCell.textLabel.font = [UIFont systemFontOfSize:13.0];
                sectionCell.detailTextLabel.font = [UIFont boldSystemFontOfSize:13.0];
                sectionCell.detailTextLabel.textColor = [UIColor blackColor];
            }
            
            if(mChildrenCount == 0)
            {
                [self priceDetailsWithoutChildren:sectionCell withIndexPath:indexPath];
            }
            else
            {
                [self priceDetailsWithAdultsAndChildren:sectionCell withIndexPath:indexPath];
            }
            tempCell = sectionCell;
        }
    }
    else
    {
        if(indexPath.section == 1)
        {
            AirwalaTicketDetailsCell *sectionCell = [tableView dequeueReusableCellWithIdentifier:CellId];
            
            if(sectionCell == nil)
            {
                sectionCell = [[AirwalaTicketDetailsCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellId];
                sectionCell.textLabel.font = [UIFont systemFontOfSize:13.0];
                sectionCell.detailTextLabel.font = [UIFont boldSystemFontOfSize:13.0];
                sectionCell.detailTextLabel.textColor = [UIColor blackColor];
            }
            
            if(mChildrenCount == 0)
            {
                [self priceDetailsWithoutChildren:sectionCell withIndexPath:indexPath];
            }
            else
            {
                [self priceDetailsWithAdultsAndChildren:sectionCell withIndexPath:indexPath];
            }
            tempCell = sectionCell;
        }
    }
    tempCell.selectionStyle = UITableViewCellSelectionStyleNone;
    return tempCell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [mTableHeaderNamesArray objectAtIndex:section];
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Action Methods

- (void)bookTicket:(id)sender
{
    AirwalaPassengerDetailsViewController *passengerDetailsController = [[AirwalaPassengerDetailsViewController alloc]initWithNibName:@"AirwalaPassengerDetailsViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:passengerDetailsController animated:YES];

    NSString *routingString = [self formatRoutingDetails:self.selectedRoutingDetailsDict];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:routingString forKey:kRoutingDetails];
    [userDefaults synchronize];
}

- (void)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Instance Methods

- (void)priceDetailsWithoutChildren:(AirwalaTicketDetailsCell *)cell withIndexPath:(NSIndexPath *)indexPath
{
    cell.textLabel.text = [mOnlyAdultsArray objectAtIndex:indexPath.row];
    
    if(indexPath.row == 0)
    {
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ * %d",self.adultBasePriceString,mAdultCount];
    }
    else if(indexPath.row == 1)
    {
        cell.detailTextLabel.text = [self calculateTotalTax];
    }
    else
    {
        cell.detailTextLabel.text = [NSString stringWithFormat:@"$%@",totalPriceString];
    }
}

- (void)priceDetailsWithAdultsAndChildren:(AirwalaTicketDetailsCell *)cell withIndexPath:(NSIndexPath *)indexPath
{
    cell.textLabel.text = [mPriceCategoryArray objectAtIndex:indexPath.row];
    
    if(indexPath.row == 0)
    {
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ * %d",self.adultBasePriceString,mAdultCount];
    }
    else if(indexPath.row == 1)
    {
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ * %d",self.childBasePriceString,mChildrenCount];
    }
    else if(indexPath.row == 2)
    {
        cell.detailTextLabel.text = [self calculateTotalTax];
    }
    else
    {
        cell.detailTextLabel.text = [NSString stringWithFormat:@"$%@",totalPriceString];
    }
}

- (NSString *)calculateTotalTax
{
    float adultTaxValue = [adultTaxString floatValue];
    float childTaxValue = [childTaxString floatValue];
    return [NSString stringWithFormat:@"%0.2f", (adultTaxValue * mAdultCount) + (childTaxValue * mChildrenCount)];
}

#pragma mark - Methods For Formatting Dictionary

- (NSString *)formatRoutingDetails:(NSDictionary *)routingDict
{
    NSMutableString *routingString = [NSMutableString string];
    
    for (NSString *key in routingDict)
    {
        id tempValue = [routingDict valueForKey:key];
        if([tempValue isKindOfClass:[NSArray class]])
        {
            NSArray *value = tempValue;
            [routingString appendFormat:@"\"%@\":%@,",key,[self manageTripDetails:value]];
        }
        else if([tempValue isKindOfClass:[NSString class]])
        {
            NSString *value = tempValue;
            [routingString appendFormat:@"\"%@\":\"%@\",",key,value];
        }
    }
    [routingString deleteCharactersInRange:NSMakeRange([routingString length] - 1, 1)];
    return [NSString stringWithFormat:@"{%@}",routingString];
}

- (NSString *)manageTripDetails:(NSArray *)tripArray
{
    NSMutableString *tripString = [[NSMutableString alloc]init];
    NSMutableString *tempString;
    
    for (NSDictionary *segmentDict in tripArray)
    {
        tempString = [NSMutableString string];
        NSArray *segmentArray = [segmentDict valueForKey:@"segments"];
        for (NSDictionary *dict in segmentArray)
        {
            [tempString appendFormat:@"%@,",[AirwalaUtilities formatDictionaryDetails:dict]];
        }
        [tempString deleteCharactersInRange:NSMakeRange([tempString length] - 1, 1)];
        tempString = [NSString stringWithFormat:@"{\"segments\":[%@]},",tempString];
        [tripString appendString:tempString];
    }
    [tripString deleteCharactersInRange:NSMakeRange([tripString length] - 1, 1)];
    return [NSString stringWithFormat:@"[%@]",tripString];
}

#pragma mark - Custom Init

- (void)customInitialization
{
    self.airlineImage = [[UIImage alloc]init];
    self.airlineNameString = [[NSString alloc]init];
    if(![[[NSUserDefaults standardUserDefaults]objectForKey:kTripType] isEqualToString:kOneWay])
        mTableHeaderNamesArray = [[NSArray alloc]initWithObjects:@"Upward Journey Details", @"Return Journey Details", @"Price Details", nil];
    else
        mTableHeaderNamesArray = [[NSArray alloc]initWithObjects:@"Journey Details", @"Price Details", nil];
    mPriceCategoryArray = [[NSArray alloc]initWithObjects:@"Adults", @"Children", @"Taxes and other fees", @"Total Amount", nil];
    mOnlyAdultsArray = [[NSArray alloc]initWithObjects:@"Adults", @"Taxes and other fees", @"Total Amount", nil];
}

@end
