//
//  AirwalaDatePickerViewController.m
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 31/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AirwalaDatePickerViewController.h"
#import "UIViewController+MHSemiModal.h"

@interface AirwalaDatePickerViewController ()

- (void)customInitialization;

@end

@implementation AirwalaDatePickerViewController

@synthesize datePicker;
@synthesize pickerView;
@synthesize canShowPickerView;
@synthesize selectedTextField;
@synthesize delegate = mDelegate;
@synthesize defaultDate = mDefaultDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

#pragma mark - View Hierarchy

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (!canShowPickerView)
    {
        [pickerView removeFromSuperview];
        self.datePicker.timeZone = [NSTimeZone systemTimeZone];
        if (self.defaultDate != nil)
        {
            self.datePicker.date = self.defaultDate;
        }
        else
        {
            self.datePicker.date = [NSDate date];
        }
    }
    else
    {
        [self customInitialization];
        [pickerView selectRow:2 inComponent:0 animated:NO];
        [pickerView selectRow:2 inComponent:1 animated:NO];
        mMonthString = @"March";
        mYearString = @"2014";
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - PickerView DataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSInteger count;
    
    if(component == 0)
        count = 12;
    else
        count = 20;
    
    return count;
}

#pragma mark - PickerView Delegates

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component == 0) {
        return [mMonthsArray objectAtIndex:row];
    }
    else
        return [NSString stringWithFormat:@"%d",row + 2012];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if(component == 0)
    {
        mMonthString = [mMonthsArray objectAtIndex:row];
    }
    else
        
    {
        mYearString = [NSString stringWithFormat:@"%d",row + 2012];
    }
}

#pragma mark - Action Methods

- (IBAction)done:(id)sender
{
    if (canShowPickerView)
    {
        if(mDelegate && [mDelegate respondsToSelector:@selector(setYearAndMonth:andTextField:)])
            [mDelegate setYearAndMonth:[NSString stringWithFormat:@"%@, %@",mMonthString,mYearString] andTextField:selectedTextField];
    }
    else
    {
        if (mDelegate && [mDelegate respondsToSelector:@selector(setDate:andTextField:)])
            [mDelegate setDate:self.datePicker.date andTextField:selectedTextField];
    }
    [self mh_dismissSemiModalViewController:self animated:YES];  
    
}

- (IBAction)cancel:(id)sender
{
    if (canShowPickerView)
    {
        if(mDelegate && [mDelegate respondsToSelector:@selector(setYearAndMonth:andTextField:)])
            [mDelegate setYearAndMonth:nil andTextField:nil];
    }
    else
    {
        if (mDelegate && [mDelegate respondsToSelector:@selector(setDate:andTextField:)])
            [mDelegate setDate:nil andTextField:nil];
    }
    [self mh_dismissSemiModalViewController:self animated:YES];  
}

#pragma mark - Local Method

- (void)customInitialization
{
    mMonthsArray = [[NSArray alloc]initWithObjects:@"January",@"February",@"March",@"April",@"May",@"June",@"July",@"August",@"September",@"October",@"November",@"December", nil];
    mYearString = [[NSString alloc]init];
    mMonthString = [[NSString alloc]init];
}

@end
