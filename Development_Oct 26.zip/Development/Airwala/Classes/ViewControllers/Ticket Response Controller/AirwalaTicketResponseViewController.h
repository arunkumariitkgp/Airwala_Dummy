//
//  AirwalaTicketResponseViewController.h
//  Airwala
//
//  Created by startupsourcing on 28/09/12.
//
//

#import <UIKit/UIKit.h>

@interface AirwalaTicketResponseViewController : UIViewController
{
    IBOutlet UILabel *firstResponseLabel;
    IBOutlet UILabel *secondResponseLabel;
    IBOutlet UILabel *thirdResponseLabel;
    IBOutlet UIImageView *imageView;
    NSString *firstResponseName;
    NSString *thirdResponseName;
}

@property (nonatomic, strong) NSString *secondResponseName;
@property (nonatomic, strong) UIImage *responseImage;
@property (assign) BOOL canShowSuccessResponse;

@end
