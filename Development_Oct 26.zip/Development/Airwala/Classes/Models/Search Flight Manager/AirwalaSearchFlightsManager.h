//
//  AirwalaSearchFlightsManager.h
//  Airwala
//
//  Created by startupsourcing on 04/09/12.
//
//

#import <Foundation/Foundation.h>

@protocol AirwalaSearchFlightDelegate <NSObject>

@optional

- (void)updateFlightList:(NSMutableDictionary *)flightListDict;
- (void)flightListOperationFailed;

@end

@interface AirwalaSearchFlightsManager : NSObject<AirwalaOperationFailedDelegate>
{
    NSMutableDictionary *mFlightListDict;
    id<AirwalaSearchFlightDelegate> searchFlightDelegate;
}

@property (nonatomic, strong) MKNetworkOperation *flightListOperation;

#pragma mark - Shared Instance

+ (AirwalaSearchFlightsManager *) sharedInstance;

#pragma mark - Instance Methods

- (void)setSearchFlightDelegate:(id<AirwalaSearchFlightDelegate>)sender;

- (void)findFlightsListForRoundTripWithSourceAirport:(NSString *)sourceAirport
                                  destinationAirport:(NSString *)destinationAirport
                                       departureDate:(NSString *)depDate
                                          returnDate:(NSString *)retDate
                                      numberOfAdults:(int)adults
                                    numberOfChildren:(int)children
                                        andClassType:(NSString *)classType;

- (void)findFlightsListForOneWayWithSourceAirport:(NSString *)sourceAirport
                               destinationAirport:(NSString *)destinationAirport
                                    departureDate:(NSString *)depDate
                                   numberOfAdults:(int)adults
                                 numberOfChildren:(int)children
                                     andClassType:(NSString *)classType;

- (void)checkingForExistanceOfDelegate;

@end
