//
//  AirwalaBookTicketManager.h
//  Airwala
//
//  Created by startupsourcing on 12/09/12.
//
//

#import <Foundation/Foundation.h>

@protocol AirwalaBookTicketDelegate <NSObject>

@optional

- (void)bookTicketResponse:(NSMutableDictionary *)responseDict;
- (void)bookTicketOperationFialed;

@end


@interface AirwalaBookTicketManager : NSObject<AirwalaOperationFailedDelegate>
{
    NSMutableDictionary *mBookingResopnseDict;
    id<AirwalaBookTicketDelegate> bookTicketDelegate;
}

@property (nonatomic, strong) MKNetworkOperation *bookTicketOperation;
@property (nonatomic, strong) MKNetworkOperation *emailTicketOperation;

#pragma mark - Shared Instance

+ (AirwalaBookTicketManager *) sharedInstance;

#pragma mark - Instance Methods

- (void)setBookTicketDelegate:(id<AirwalaBookTicketDelegate>)sender;
- (void)checkingForExistanceOfDelegate;
- (void)bookTicketWithNoOfAdults:(int)adultCount
                    noOfChildren:(int)childCount
                         routing:(NSString *)routingDetails
                      passengers:(NSString *)passengerDetails
                         payment:(NSString *)paymentDetails
                         contact:(NSString *)contactDetails
                     andClientIP:(NSString *)clientIP;
- (void)emailTicketWithMailID:(NSString *)mailID
    andConfirmationCode:(NSString *)confirmationCode;

@end
