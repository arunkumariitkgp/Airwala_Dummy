//
//  AirwalaAirportListManager.m
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 03/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"
#import "AirwalaWebEngine.h"
#import "AirwalaAirportListManager.h"

@implementation AirwalaAirportListManager

@synthesize getAirportListOperation;
@synthesize airportsListDict;

#pragma mark - Singleton Methods

static  AirwalaAirportListManager *sharedInstance = nil;

+ (AirwalaAirportListManager*) sharedInstance
{
    @synchronized(self)
    {
        if (sharedInstance == nil)
		{
			sharedInstance = [[AirwalaAirportListManager alloc] init];
		}
    }
    return sharedInstance;
}

+ (id)allocWithZone:(NSZone *)zone 
{
    @synchronized(self) 
	{
        if (sharedInstance == nil) 
		{
            sharedInstance = [super allocWithZone:zone];
            return sharedInstance;  // assignment and return on first allocation
        }
    }
    return nil; // on subsequent allocation attempts return nil
}

- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (id) init
{
    self = [super init];
    if (self)
    {
        selectedTextField = [[UITextField alloc]init];
        getAirportListOperation = [[MKNetworkOperation alloc]init];
    }
    
    return self;
}


#pragma mark - Helper Methods

- (void)setAirportListDelegate:(id<AirportManagerDelegate>)sender
{
    airportListDelegate = sender;
}

- (void)getAirportsListWithTextField:(UITextField *)textField
{
    [getAirportListOperation setOperationFailedDelegate:self];
    self.getAirportListOperation = [AIRWALA_APP_DELEGATE.webEngine airportListWithCustomerId:@"I3I6P1"
                                                                           customerSessionId:@"12345"
                                                                                searchString:textField.text
                                                                         withCompletionBlock:^(id parsedObjects, NSDictionary *userInfo){
                                                                             if (self.airportsListDict) {
                                                                                 self.airportsListDict = nil;
                                                                                 self.airportsListDict = [parsedObjects mutableCopy];
                                                                             }
                                                                             else
                                                                                 self.airportsListDict = [parsedObjects mutableCopy];
                                                                             [textField resignFirstResponder];
                                                                             selectedTextField = textField;
                                                                             [self checkingForExistanceOfDelegate:textField];
                                                                         }
                                                                               andErrorBlock:^(NSError *error){
                                                                                   DLog(@"Airport List:  ERRORRRRRR");
                                                                               }];
}

- (void)getAirportsListWithString:(NSString *)string
{
    [getAirportListOperation setOperationFailedDelegate:self];
    self.getAirportListOperation = [AIRWALA_APP_DELEGATE.webEngine airportListWithCustomerId:@"I3I6P1"
                                                                           customerSessionId:@"12345"
                                                                                searchString:string
                                                                         withCompletionBlock:^(id parsedObjects, NSDictionary *userInfo){
                                                                             if (self.airportsListDict) {
                                                                                 self.airportsListDict = nil;
                                                                                 self.airportsListDict = [parsedObjects mutableCopy];
                                                                             }
                                                                             else
                                                                                 self.airportsListDict = [parsedObjects mutableCopy];
                                                                             [self delegateForLocation];
                                                                         }
                                                                               andErrorBlock:^(NSError *error){
                                                                                   DLog(@"Airport List:  ERRORRRRRR");
                                                                               }];

}

- (void)checkingForExistanceOfDelegate:(UITextField *)textField
{
    if(airportListDelegate && [airportListDelegate respondsToSelector:@selector(didAirportListDataUpdated:andTextField:)])
    {
        [airportListDelegate didAirportListDataUpdated:self.airportsListDict andTextField:textField];
    }
}

- (void)operationFailed
{
    if (airportListDelegate && [airportListDelegate respondsToSelector:@selector(airportListOperationFailed:)])
    {
        [airportListDelegate airportListOperationFailed:selectedTextField];
    }
}

- (void)delegateForLocation
{
    if (airportListDelegate && [airportListDelegate respondsToSelector:@selector(airportListForLocationManager:)])
    {
        [airportListDelegate airportListForLocationManager:self.airportsListDict];
    }
}

@end
