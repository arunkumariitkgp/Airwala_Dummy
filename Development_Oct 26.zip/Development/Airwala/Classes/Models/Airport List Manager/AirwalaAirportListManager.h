//
//  AirwalaAirportListManager.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 03/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol AirportManagerDelegate <NSObject>

@optional

- (void)didAirportListDataUpdated:(NSMutableDictionary *)updatedDict andTextField:(UITextField *)textField;
- (void)selectedAirportName:(NSString *)airportName andTextField:(UITextField *)textField;
- (void)journeyTypeSelected:(NSString *)journeyType andTextField:(UITextField *)textField;
- (void)airportListForLocationManager:(NSMutableDictionary *)updatedDict;
- (void)airportListOperationFailed:(UITextField *)textField;
- (void)cancelSelectingAirport;

@end

@interface AirwalaAirportListManager : NSObject<AirwalaOperationFailedDelegate>
{
    id<AirportManagerDelegate> airportListDelegate;
    UITextField *selectedTextField;
}

#pragma mark - Accessible Properties

@property (nonatomic, strong) MKNetworkOperation *getAirportListOperation;
@property (nonatomic, strong) NSMutableDictionary *airportsListDict;

#pragma mark - Shared Instance

+ (AirwalaAirportListManager *) sharedInstance;

#pragma mark - Instance Methods

- (void) setAirportListDelegate:(id<AirportManagerDelegate>)sender;
- (void) getAirportsListWithTextField:(UITextField *)textField;
- (void) getAirportsListWithString:(NSString *)string;
- (void) checkingForExistanceOfDelegate:(UITextField *)textField;
- (void) delegateForLocation;

@end
