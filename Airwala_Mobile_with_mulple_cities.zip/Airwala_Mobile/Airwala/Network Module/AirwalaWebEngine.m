//
//  AirwalaWebEngine.m
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AirwalaWebEngine.h"
#import "AirwalaUtilities.h"

@implementation AirwalaWebEngine

- (BOOL) isReachable
{
	BOOL networkAvailable = NO;
	
	Reachability *reachability = [Reachability reachabilityForInternetConnection];
	
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
	
    networkAvailable = (networkStatus!= NotReachable);
    
    return networkAvailable;
}

#pragma mark - Airports List API

- (MKNetworkOperation *)airportListWithCustomerId:(NSString *)customerId 
                                customerSessionId:(NSString *)customerSessionId 
                                     searchString:(NSString *)searchString 
                              withCompletionBlock:(RequestSuccessBlock)successBlock 
                                    andErrorBlock:(RequestErrorBlock)errorBlock
{
    NSMutableDictionary *paramDict = [NSMutableDictionary dictionary];
	[paramDict setObject:customerId forKey:kCustomerId];
	[paramDict setObject:customerSessionId forKey:kCustomerSessionId];
	[paramDict setObject:searchString forKey:kInputString];   
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:@"Airports List", kRequestType, nil];
    
    MKNetworkOperation *registerOperation = [self operationWithPath:@"airticket/v1/airport.aspx" 
                                                             params:paramDict
                                                         httpMethod:kGETRequest];
    [registerOperation setPostDataEncoding:MKNKPostDataEncodingTypeURL];
    
    [registerOperation onCompletion:^(MKNetworkOperation *completedOperation) {
        dispatch_queue_t parsingQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_async(parsingQueue, ^{
            
            NSError *error;
            id responseValue = [NSJSONSerialization JSONObjectWithData:[completedOperation responseData] options:kNilOptions error:&error];
            dispatch_async(dispatch_get_main_queue(), ^{
                successBlock(responseValue, userInfo);
            });
        });
        
    } onError:^(NSError *error) {
//        [self errorHandler:error errorBlock:errorBlock];
    }];
    
    [self enqueueOperation:registerOperation];
    return registerOperation;
}

#pragma mark - Search Air Ticket API

- (MKNetworkOperation *)searchAirTicketWithCustomerId:(NSString *)customerId 
                                    customerSessionId:(NSString *)customerSessionId
                                     departureAirport:(NSString *)departureAirportName 
                                   destinationAirport:(NSString *)destinationAirportName   
                                        departureDate:(NSString *)departureDate 
                                           returnDate:(NSString *)returningDate 
                                        typeOfJourney:(NSString *)type 
                                       numberOfAdults:(int)adults 
                                    numberOfChildrens:(int)children
                                            classType:(NSString *)classType
                                  withCompletionBlock:(RequestSuccessBlock)successBlock
                                        andErrorBlock:(RequestErrorBlock)errorBlock
                                  
{
    NSMutableDictionary *paramDict = [NSMutableDictionary dictionary];
	[paramDict setObject:customerId forKey:kCustomerId];
	[paramDict setObject:customerSessionId forKey:kCustomerSessionId];
	[paramDict setObject:departureAirportName forKey:kDepartureAirport];
    [paramDict setObject:destinationAirportName forKey:kDestinationAirport];
    [paramDict setObject:departureDate forKey:kDepartureDate];
    [paramDict setObject:returningDate forKey:kReturnDate];
    [paramDict setObject:type forKey:kTypeOfJourney];
    [paramDict setObject:[NSNumber numberWithInt:adults] forKey:kAdults];
    [paramDict setObject:[NSNumber numberWithInt:children] forKey:kChildren];
    [paramDict setObject:classType forKey:kClassType];
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:@"Search Air Ticket List", kRequestType, nil];
    
    MKNetworkOperation *registerOperation = [self operationWithPath:@"airticket/v1/list.aspx" 
                                                             params:paramDict
                                                         httpMethod:kGETRequest];
    [registerOperation setPostDataEncoding:MKNKPostDataEncodingTypeJSON];
    
    [registerOperation onCompletion:^(MKNetworkOperation *completedOperation) {
        dispatch_queue_t parsingQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_async(parsingQueue, ^{
            
            NSError *error;
            id responseValue = [NSJSONSerialization JSONObjectWithData:[completedOperation responseData] options:kNilOptions error:&error];
            dispatch_async(dispatch_get_main_queue(), ^{
                successBlock(responseValue, userInfo);
            });
        });
        
    } onError:^(NSError *error) { 
        //        [self errorHandler:error errorBlock:errorBlock];
    }];
    
    [self enqueueOperation:registerOperation];
    return registerOperation;
}

#pragma mark - Book Ticket API

- (MKNetworkOperation *)bookTicketWithCustomerId:(NSString *)customerId
                               customerSessionId:(NSString *)customerSessionId
                                      noOfAdults:(int)adultCount
                                    noOfChildren:(int)childCount
                                         routing:(NSString *)routingDetails
                                      passengers:(NSString *)passengerDetails
                                         payment:(NSString *)paymentDetails
                                         contact:(NSString *)contactDetails
                                     andClientIP:(NSString *)clientIP
                             withCompletionBlock:(RequestSuccessBlock)successBlock
                                   andErrorBlock:(RequestErrorBlock)errorBlock
{
    NSMutableDictionary *paramDict = [NSMutableDictionary dictionary];
	[paramDict setObject:customerId forKey:kCustomerId];
	[paramDict setObject:customerSessionId forKey:kCustomerSessionId];
    [paramDict setObject:[NSNumber numberWithInt:adultCount] forKey:kAdults];
    [paramDict setObject:[NSNumber numberWithInt:childCount] forKey:kChildren];
    [paramDict setObject:routingDetails forKey:kRouting];
    [paramDict setObject:passengerDetails forKey:kPassengers];
    [paramDict setObject:paymentDetails forKey:kPayment];
    [paramDict setObject:contactDetails forKey:kContact];
    [paramDict setObject:clientIP forKey:kClientIp];
            
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:@"Book Air Ticket List", kRequestType, nil];
    
    MKNetworkOperation *registerOperation = [self operationWithPath:@"airticket/v1/res.aspx"
                                                             params:paramDict
                                                         httpMethod:kGETRequest
                                                                ssl:YES];
    [registerOperation setPostDataEncoding:MKNKPostDataEncodingTypeJSON];
    [registerOperation onCompletion:^(MKNetworkOperation *completedOperation) {
        dispatch_queue_t parsingQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_async(parsingQueue, ^{
            
            NSError *error;
            id responseValue = [NSJSONSerialization JSONObjectWithData:[completedOperation responseData] options:kNilOptions error:&error];
            DLog(@"BOOK API RESPONSE:  %@",responseValue);
            dispatch_async(dispatch_get_main_queue(), ^{
                successBlock(responseValue, userInfo);
            });
        });
        
    } onError:^(NSError *error) {
        //        [self errorHandler:error errorBlock:errorBlock];
    }];
    
    [self enqueueOperation:registerOperation];
    return registerOperation;
}

@end
