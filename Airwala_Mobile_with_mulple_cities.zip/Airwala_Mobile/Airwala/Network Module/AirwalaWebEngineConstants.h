//
//  AirwalaWebEngineConstants.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef Airwala_AirwalaWebEngineConstants_h
#define Airwala_AirwalaWebEngineConstants_h

#define kRequestType        @"RequestType"
#define kGETRequest         @"GET"
#define kPOSTRequest        @"POST"
#define kDELETERequest      @"DELETE"
#define kPUTRequest         @"PUT"

#define kCustomerId         @"cid"
#define kCustomerSessionId  @"customerSessionId"
#define kInputString        @"string"
#define kDepartureAirport   @"departureAirport"
#define kDestinationAirport @"destinationAirport" 
#define kDepartureDate      @"departureDate"
#define kReturnDate         @"returnDate" 
#define kTypeOfJourney      @"type"
#define kAdults             @"adults" 
#define kChildren           @"children"
#define kClassType          @"cabin"

#define kRouting            @"routing"
#define kMainAirlineCode    @"mainAirlineCode"
#define kMainAirlineName    @"mainAirlineName"
#define kTotalPrice         @"totalPrice"
#define kAdultBasePrice     @"adultBasePrice"
#define kAdultTax           @"adultTax"
#define kChildrenBasePrice  @"childBasePrice"
#define kChildTax           @"childTax"
#define kLastTicketDate     @"lastTicketDate"
#define kTrips              @"trips"
#define kSegments           @"segments"
#define kPassengers         @"passengers"
#define kPayment            @"payment"
#define kContact            @"contact"
#define kClientIp           @"clientIp"


#endif
