//
//  AirwalaBookTicketManager.m
//  Airwala
//
//  Created by startupsourcing on 12/09/12.
//
//

#import "AppDelegate.h"
#import "AirwalaWebEngine.h"
#import "AirwalaBookTicketManager.h"

@implementation AirwalaBookTicketManager

@synthesize bookTicketOperation;

#pragma mark - Singleton Methods

static  AirwalaBookTicketManager *sharedInstance = nil;

+ (AirwalaBookTicketManager*) sharedInstance
{
    @synchronized(self)
    {
        if (sharedInstance == nil)
		{
			sharedInstance = [[AirwalaBookTicketManager alloc] init];
		}
    }
    return sharedInstance;
}

+ (id)allocWithZone:(NSZone *)zone
{
    @synchronized(self)
	{
        if (sharedInstance == nil)
		{
            sharedInstance = [super allocWithZone:zone];
            return sharedInstance;  // assignment and return on first allocation
        }
    }
    return nil; // on subsequent allocation attempts return nil
}

- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (id) init
{
    self = [super init];
    if (self)
    {
        mBookingResopnseDict = [[NSMutableDictionary alloc]init];
    }    
    return self;
}

#pragma mark - Instance Methods

- (void)setBookTicketDelegate:(id<AirwalaBookTicketDelegate>)sender
{
    bookTicketDelegate = sender;
}

- (void)bookTicketWithNoOfAdults:(int)adultCount
                    noOfChildren:(int)childCount
                         routing:(NSString *)routingDetails
                      passengers:(NSString *)passengerDetails
                         payment:(NSString *)paymentDetails
                         contact:(NSString *)contactDetails
                     andClientIP:(NSString *)clientIP
{
    self.bookTicketOperation.operationFailedDelegate = self;
    self.bookTicketOperation = [AIRWALA_APP_DELEGATE.bookWebEngine bookTicketWithCustomerId:@"I3I6P1"
                                                                          customerSessionId:@"12345"
                                                                                 noOfAdults:adultCount
                                                                               noOfChildren:childCount
                                                                                    routing:routingDetails
                                                                                 passengers:passengerDetails
                                                                                    payment:paymentDetails
                                                                                    contact:contactDetails
                                                                                andClientIP:clientIP
                                                                        withCompletionBlock:^(id parsedObject, NSDictionary *userInfo){
                                                                            mBookingResopnseDict = [parsedObject mutableCopy];
                                                                            [self checkingForExistanceOfDelegate];
                                                                        }andErrorBlock:^(NSError *error){
                                                                            DLog(@"booking ticket : ERRORRRRRR");
                                                                        }];
}

- (void)checkingForExistanceOfDelegate
{
    if (bookTicketDelegate && [bookTicketDelegate respondsToSelector:@selector(bookTicketResponse:)]) {
        [bookTicketDelegate bookTicketResponse:mBookingResopnseDict];
    }
}

- (void)operationFailed
{
    if (bookTicketDelegate && [bookTicketDelegate respondsToSelector:@selector(bookTicketOperationFialed)])
    {
        [bookTicketDelegate bookTicketOperationFialed];
    }
}

@end
