//
//  AirwalaCustomScrollView.m
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 31/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AirwalaCustomScrollView.h"

@implementation AirwalaCustomScrollView

@synthesize delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(scrollViewTouched)]) 
    {
        [self.delegate scrollViewTouched];
    }
}

@end
