//
//  AirwalaContactDetailsViewController.h
//  Airwala
//
//  Created by startupsourcing on 27/09/12.
//
//

#import <UIKit/UIKit.h>
#import "AirwalaTextField.h"
#import "AirwalaBookTicketManager.h"
#import "AirwalaDatePickerViewController.h"

@interface AirwalaContactDetailsViewController : UIViewController <UITextFieldDelegate, AirwalaDatePickerViewControllerDelegate, AirwalaBookTicketDelegate>
{
    NSArray *mRowNamesArray;
    NSArray *mPlaceHoldersArray;
    NSArray *mTextFieldReferenceArray;

    AirwalaTextField *mCityField;
    AirwalaTextField *mEmailField;
    AirwalaTextField *mStateField;
    AirwalaTextField *mCountryField;
    AirwalaTextField *mZipCodeField;
    AirwalaTextField *mLastNameField;
    AirwalaTextField *mFirstNameField;
    AirwalaTextField *mMiddleNameField;
    AirwalaTextField *mAddressOneField;
    AirwalaTextField *mAddressTwoField;
    AirwalaTextField *mPhoneNumberField;
}

@property (nonatomic, strong) IBOutlet UITableView *contactDetailsTableView;

@end