//
//  AirwalaPassengerDetailsViewController.m
//  Airwala
//
//  Created by startupsourcing on 24/09/12.
//
//

#import "UIViewController+MHSemiModal.h"
#import "AirwalaPaymentDetailsViewController.h"
#import "AirwalaPassengerDetailsViewController.h"

@interface AirwalaPassengerDetailsViewController ()

- (void)customInitialization;
- (void)formatNumberOfSections;
- (void)resigningFirstResponders;
- (void)resetTextFields:(NSMutableArray *)array;
- (BOOL)isAnyTextFieldEmpty;
- (void)saveLatestData;
- (void)displayExistingData;
- (BOOL)didDataCompatibleInTermsOfAdults:(NSArray *)array;
- (NSString *)formatPassengerDetails:(NSDictionary *)passengerDict;

@end

@implementation AirwalaPassengerDetailsViewController

@synthesize passengerDetailsTableView;
@synthesize previousPassengerButton;
@synthesize nextPassengerButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        [self customInitialization];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImage *backButtonImageNormal = [UIImage imageNamed:@"topbar_button_back"];
    UIImage *backButtonImagePressed = [UIImage imageNamed:@"topbar_button_back_pressed"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:backButtonImageNormal forState:UIControlStateNormal];
    [backButton setImage:backButtonImagePressed forState:UIControlStateSelected];
    
    backButton.frame = CGRectMake(0, 0, backButtonImageNormal.size.width, backButtonImageNormal.size.height);
    
    [backButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = customBarItem;
    
    UIImage *buttonImageNormal = [UIImage imageNamed:@"topbar_button"];
    UIImage *buttonImagePressed = [UIImage imageNamed:@"topbar_button_pressed"];
    UIButton *bookButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bookButton setBackgroundImage:buttonImageNormal forState:UIControlStateNormal];
    [bookButton setBackgroundImage:buttonImagePressed forState:UIControlStateSelected];
    [bookButton setTitle:@"Next" forState:UIControlStateNormal];
    [bookButton setTitle:@"Next" forState:UIControlStateSelected];
    bookButton.titleLabel.font = [UIFont boldSystemFontOfSize:13.0];
    
    bookButton.frame = CGRectMake(0, 0, buttonImageNormal.size.width, buttonImageNormal.size.height);
    
    [bookButton addTarget:self action:@selector(next:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBar = [[UIBarButtonItem alloc] initWithCustomView:bookButton];
    self.navigationItem.rightBarButtonItem = customBar;

    if(mAdultCount + mChildrenCount == 1)
    {
        self.navigationItem.rightBarButtonItem.enabled = YES;
        self.nextPassengerButton.enabled = NO;
    }
    else
    {
        self.navigationItem.rightBarButtonItem.enabled = NO;
    }
    self.previousPassengerButton.enabled = NO;
    passengerDetailsTableView.scrollEnabled = NO;
    [self formatNumberOfSections];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGesture:)];
    [passengerDetailsTableView addGestureRecognizer:tapGesture];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
//    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"Next"
//                                                                             style:UIBarButtonItemStyleBordered
//                                                                            target:self
//                                                                            action:@selector(next:)];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellId = @"Cell Identifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellId];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellId];
    }
    
    cell.textLabel.font = [UIFont systemFontOfSize:15.0];
    cell.textLabel.text = [mRowNamesArray objectAtIndex:indexPath.row];
    cell.textLabel.numberOfLines = 2;

    AirwalaTextField *textField = [mTextFieldReferenceArray objectAtIndex:indexPath.row];
    textField.tag = indexPath.row + kFirstNameFieldTag;
    textField.delegate = self;
    textField.frame = CGRectMake(cell.frame.origin.x + 50, cell.frame.origin.y + 7, 150, 35);
    textField.backgroundColor = [UIColor clearColor];
    textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    textField.autocorrectionType = UITextAutocorrectionTypeNo;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    textField.placeholder = [mPlaceHolderNamesArray objectAtIndex:indexPath.row];
    cell.accessoryView = textField;
    [cell addSubview:[mTextFieldReferenceArray objectAtIndex:indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [mSectionNamesArray objectAtIndex:mCount - 1];
}

#pragma mark - UITextField Delegates

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    BOOL shouldBeginEditing;
    
    if(textField.tag == kDOBFieldTag)
    {
        shouldBeginEditing = NO;
        [self resigningFirstResponders];
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 120.0) andContentSize:CGSizeMake(320.0, 600.0)];
        
        AirwalaDatePickerViewController *datePickerViewController = [[AirwalaDatePickerViewController alloc] initWithNibName:@"AirwalaDatePickerViewController" bundle:[NSBundle mainBundle]];
        datePickerViewController.canShowPickerView = NO;
        datePickerViewController.delegate = self;
        datePickerViewController.selectedTextField = textField;
        
        [self mh_presentSemiModalViewController:datePickerViewController animated:YES];
    }
    else if(textField.tag == kGenderFieldTag)
    {
        shouldBeginEditing = NO;
        [self resigningFirstResponders];        
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 130.0) andContentSize:CGSizeMake(320.0, 600.0)];
        
        UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"Select Gender" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Male",@"Female",nil];
        actionSheet.tag = kActionSheetGenderTag;
        [actionSheet showInView:self.view];
    }
    else if (textField.tag == kTypeFieldTag)
    {
        shouldBeginEditing = NO;
        [self resigningFirstResponders];
        
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 100.0) andContentSize:CGSizeMake(320.0, 600.0)];
        
        UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"Select Type" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Adult",@"Child",nil];
        actionSheet.tag = kActionSheetTypeTag;
        [actionSheet showInView:self.view];

    }
    else
    {
        shouldBeginEditing = YES;
    }
    return shouldBeginEditing;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
    return YES;
}

#pragma mark - Action Methods

- (IBAction)nextPassenger:(id)sender
{
    if([self isAnyTextFieldEmpty])
    {
        ModalAlert(@"Empty Fields", @"Please give full details", @"OK", nil, nil, nil);
        return;
    }
    previousPassengerButton.enabled = YES;
    [self saveLatestData];

    mCount ++;
    
    if(mCount >= mAdultCount + mChildrenCount)
    {
        nextPassengerButton.enabled = NO;
        self.navigationItem.rightBarButtonItem.enabled = YES;
    }
    [self displayExistingData];
    [self.passengerDetailsTableView reloadData];
}

- (IBAction)previousPassenger:(id)sender
{
    if([self isAnyTextFieldEmpty])
    {
        ModalAlert(@"Empty Fields", @"Please give full details", @"OK", nil, nil, nil);
        return;
    }
    nextPassengerButton.enabled = YES;
    [self saveLatestData];

    mCount --;
    [self displayExistingData];
    if(mCount == 1)
    {
        previousPassengerButton.enabled = NO;
    }
    [self.passengerDetailsTableView reloadData];
}

- (void)next:(id)sender
{
    if([self isAnyTextFieldEmpty])
    {
        ModalAlert(@"Empty Fields", @"Please give full details", @"OK", nil, nil, nil);
        return;
    }
    [self saveLatestData];
    
    NSArray *tempArray = [mTextFieldContentDict allValues];
    if (![self didDataCompatibleInTermsOfAdults:tempArray])
    {
        ModalAlert(@"Incompatible Data", @"Total number of adults not matching", @"OK", nil, nil, nil);
        return;
    }
    
    NSMutableArray *passengerDetails = [NSMutableArray array];
    for (int index = 0; index < [tempArray count]; index ++)
    {
        NSDictionary *dict = [[NSDictionary alloc]initWithObjects:[tempArray objectAtIndex:index] forKeys:mPassengerKeysArray];
        [passengerDetails addObject:dict];
    }
    
    NSDictionary *passengerDetailsDict = [[NSDictionary alloc]initWithObjectsAndKeys:passengerDetails, @"passengers", nil];
    NSString *finalString = [self formatPassengerDetails:passengerDetailsDict];

    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:finalString forKey:kPassengerDetails];
    [userDefaults synchronize];
    
    [self resigningFirstResponders];
    AirwalaPaymentDetailsViewController *paymentDetailsController = [[AirwalaPaymentDetailsViewController alloc]initWithNibName:@"AirwalaPaymentDetailsViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:paymentDetailsController animated:YES];
}

- (void)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - AirwalaDatePickerViewController delegate

- (void)setDate:(NSDate *)pickerdate andTextField:(UITextField *)textField
{
    if (pickerdate == nil)
    {
        [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
        return;
    }
    
    NSDateFormatter *displayDateFormatter = [[NSDateFormatter alloc] init];
    [displayDateFormatter setDateFormat:@"MM/dd/yyyy"];
    NSString *displayDateStr = [displayDateFormatter stringFromDate:pickerdate];
    textField.text = displayDateStr;
    
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

#pragma mark - UIActionSheet Delegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
    
    if(actionSheet.tag == kActionSheetGenderTag)
    {
        AirwalaTextField *field = (AirwalaTextField *)[passengerDetailsTableView viewWithTag:kGenderFieldTag];
        if(buttonIndex)
            field.text = kFemale;
        else
            field.text = kMale;
    }
    else
    {
        AirwalaTextField *field = (AirwalaTextField *)[passengerDetailsTableView viewWithTag:kTypeFieldTag];
        if(buttonIndex)
            field.text = kChild;
        else
            field.text = kAdult;
    }
        
}

#pragma mark - Local Methods

- (void)customInitialization
{
    self.title = @"Passenger Details";
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    mAdultCount = [defaults integerForKey:kAdultCount];
    mChildrenCount = [defaults integerForKey:kChildCount];
    mCount = 1;
    
    mRowNamesArray = [[NSArray alloc]initWithObjects:@"First Name", @"Middle Name", @"Last Name", @"Type", @"Birth Day", @"Gender", nil];
    mPlaceHolderNamesArray = [[NSArray alloc]initWithObjects:@"Enter first name", @"Enter middle name(Optional)", @"Enter last name", @"Enter type", @"Enter date of birth", @"Enter gender", nil];
    mPassengerKeysArray = [[NSArray alloc]initWithObjects:@"firstName", @"middleName", @"lastName", @"type", @"birthday", @"gender",nil];
    mSectionNamesArray = [[NSMutableArray alloc]init];
    mTextFieldContentDict = [[NSMutableDictionary alloc]init];
    
    mMiddleNameField = [[AirwalaTextField alloc]init];
    mFirstNameField = [[AirwalaTextField alloc]init];
    mLastNameField = [[AirwalaTextField alloc]init];
    mGenderField = [[AirwalaTextField alloc]init];
    mTypeField = [[AirwalaTextField alloc]init];
    mDobField = [[AirwalaTextField alloc]init];
    
    mTextFieldReferenceArray = [[NSArray alloc]initWithObjects:mFirstNameField, mMiddleNameField, mLastNameField, mTypeField, mDobField, mGenderField,nil];
}

- (void)formatNumberOfSections
{
    for (int index = 0; index < mAdultCount + mChildrenCount; index ++)
    {
        NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:6];
        [mTextFieldContentDict setObject:tempArray forKey:[NSString stringWithFormat:@"Passenger %d",index + 1]];
        [mSectionNamesArray addObject:[NSString stringWithFormat:@"Passenger %d:",index + 1]];
    }
}

- (void)saveLatestData
{
    NSMutableArray *array = [NSMutableArray array];
    for (int index = 0; index < 6; index ++)
    {
        AirwalaTextField *field = (AirwalaTextField *)[passengerDetailsTableView viewWithTag:index + 100];
        if(!field.text || [AirwalaUtilities isEmptyString:field.text])
            [array addObject:[NSString stringWithFormat:@""]];
        else
            [array addObject:field.text];
    }
    [mTextFieldContentDict removeObjectForKey:[NSString stringWithFormat:@"Passenger %d",mCount]];
    [mTextFieldContentDict setObject:array forKey:[NSString stringWithFormat:@"Passenger %d",mCount]];
}

- (void)displayExistingData
{
    NSMutableArray *arr = [mTextFieldContentDict objectForKey:[NSString stringWithFormat:@"Passenger %d",mCount]];
    if([arr count] == 0)
    {
        [self resetTextFields:nil];
    }
    else
    {
        [self resetTextFields:arr];
    }
}

- (void)animateTextFieldWithContentOffset:(CGPoint)contentOffset andContentSize:(CGSize)contentSize
{
    [UIView beginAnimations:@"moveUpAndDown" context:nil];
    [passengerDetailsTableView setContentOffset:contentOffset];
    [passengerDetailsTableView setContentSize:contentSize];
    [UIView commitAnimations];
}

#pragma mark - TextField Helper Methods

- (void)resigningFirstResponders
{
    for (int index = kFirstNameFieldTag; index <= kGenderFieldTag; index ++) {
        AirwalaTextField *tempField = (AirwalaTextField *)[passengerDetailsTableView viewWithTag:index];
        [tempField resignFirstResponder];
    }
}

- (void)resetTextFields:(NSMutableArray *)array
{
    if(!array)
    {
        for (int index = kFirstNameFieldTag; index <= kGenderFieldTag; index ++) {
            AirwalaTextField *tempField = (AirwalaTextField *)[passengerDetailsTableView viewWithTag:index];
            tempField.text = nil;
        }
    }
    else
    {
        for (int index = kFirstNameFieldTag; index <= kGenderFieldTag; index ++) {
            AirwalaTextField *tempField = (AirwalaTextField *)[passengerDetailsTableView viewWithTag:index];
            tempField.text = [array objectAtIndex:index - kFirstNameFieldTag];
        }
    }
}

- (BOOL)isAnyTextFieldEmpty
{
    for (int index = kFirstNameFieldTag; index <= kGenderFieldTag; index ++) {
        AirwalaTextField *tempField = (AirwalaTextField *)[passengerDetailsTableView viewWithTag:index];
        if([AirwalaUtilities isEmptyString:tempField.text] && tempField.tag != kMiddleNameFieldTag)
            return YES;
    }
    return NO;
}

- (void)tapGesture:(id)sender
{
    for (int index = kFirstNameFieldTag; index <= kGenderFieldTag; index ++) {
        AirwalaTextField *tempField = (AirwalaTextField *)[passengerDetailsTableView viewWithTag:index];
        [tempField resignFirstResponder];
    }
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

#pragma mark - Formatting Passenger Details

- (NSString *)formatPassengerDetails:(NSDictionary *)passengerDict
{
    NSMutableString *passengerDetailString = [NSMutableString string];
    
    NSArray *passengerDetailsArray = [passengerDict valueForKey:@"passengers"];
    for (NSDictionary *dict in passengerDetailsArray)
    {
        [passengerDetailString appendFormat:@"%@,",[AirwalaUtilities formatDictionaryDetails:dict]];
    }
    
    if([passengerDetailString length] > 0)
        [passengerDetailString deleteCharactersInRange:NSMakeRange([passengerDetailString length] - 1, 1)];
    return [NSString stringWithFormat:@"{\"passengers\":[%@]}",passengerDetailString];
}

- (BOOL)didDataCompatibleInTermsOfAdults:(NSArray *)array
{
    BOOL isCompatible;
    NSInteger count = 0;
    for (int index = 0; index < [array count]; index ++)
    {
        if([[[array objectAtIndex:index]objectAtIndex:3] isEqualToString:kAdult])
            count ++;
    }
    if (mAdultCount == count)
        isCompatible = YES;
    else
        isCompatible = NO;
    
    return isCompatible;
}

@end
