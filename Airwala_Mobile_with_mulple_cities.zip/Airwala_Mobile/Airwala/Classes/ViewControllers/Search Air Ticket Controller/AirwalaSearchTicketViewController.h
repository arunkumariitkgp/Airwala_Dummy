//
//  AirwalaSearchTicketViewController.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AirwalaConstants.h"
#import "AirwalaCustomScrollView.h"
#import "AirwalaAirportListManager.h"
#import "AirwalaSearchFlightsManager.h"
#import "AirwalaDatePickerViewController.h"

@interface AirwalaSearchTicketViewController : UIViewController<AirwalaDatePickerViewControllerDelegate, AirwalaScrollViewProtocol, AirportManagerDelegate, AirwalaSearchFlightDelegate>

#pragma mark - View Outlets

@property(nonatomic, strong)IBOutlet UIView *detailView;
@property(nonatomic, strong)IBOutlet UIButton *findFlightsButton;
@property(nonatomic, strong)IBOutlet UISegmentedControl *typeSegmentControl;
@property(nonatomic, strong)IBOutlet AirwalaCustomScrollView *thirdPageScrollView;
@property(nonatomic, strong)IBOutlet AirwalaCustomScrollView *firstPageScrollView;
@property(nonatomic, strong)IBOutlet AirwalaCustomScrollView *secondPageScrollView;


#pragma mark - Round Trip Properties

@property(nonatomic, strong)IBOutlet UITextField *toField;
@property(nonatomic, strong)IBOutlet UITextField *fromField;
@property(nonatomic, strong)IBOutlet UITextField *adultField;
@property(nonatomic, strong)IBOutlet UITextField *classField;
@property(nonatomic, strong)IBOutlet UITextField *multiToField;
@property(nonatomic, strong)IBOutlet UITextField *childrenField;
@property(nonatomic, strong)IBOutlet UITextField *multiFromField;
@property(nonatomic, strong)IBOutlet UITextField *returnDateField;
@property(nonatomic, strong)IBOutlet UITextField *departureDateField;
@property(nonatomic, strong)IBOutlet UIActivityIndicatorView *toActivityIndicator;
@property(nonatomic, strong)IBOutlet UIActivityIndicatorView *fromActivityIndicator;

#pragma mark - Instance Methods

- (IBAction)findFlights:(id)sender;

@end
