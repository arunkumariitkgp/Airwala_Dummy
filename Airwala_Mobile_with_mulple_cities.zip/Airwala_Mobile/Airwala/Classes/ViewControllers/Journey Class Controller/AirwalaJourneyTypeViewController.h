//
//  AirwalaJourneyTypeViewController.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 03/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AirwalaAirportListManager.h"

@interface AirwalaJourneyTypeViewController : UIViewController
{
    NSObject <AirportManagerDelegate>__unsafe_unretained *journeyTypeDelegate;
    NSArray *mJourneyTypeArray;
}

@property (unsafe_unretained) NSObject<AirportManagerDelegate> *journeyTypeDelegate;
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) IBOutlet UITableView *classListTableView;

- (NSString *) formatSelectedJourneyType:(NSString *)journeyType;
- (IBAction)cancel:(id)sender;

@end
