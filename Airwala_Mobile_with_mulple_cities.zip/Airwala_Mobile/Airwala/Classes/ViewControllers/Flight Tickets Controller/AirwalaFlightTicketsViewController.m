//
//  AirwalaFlightTicketsViewController.m
//  Airwala
//
//  Created by startupsourcing on 04/09/12.
//
//

#import "AirwalaFlightTicketDetailViewController.h"
#import "AirwalaFlightTicketsViewController.h"
#import "AirwalaFlightTicketsCell.h"

@interface AirwalaFlightTicketsViewController ()

- (AirwalaFlightTicketsCell *) organizeFlightTicketsDataInCell:(AirwalaFlightTicketsCell *)customCell
                                             withDepartureCode:(NSArray *)departureCodeArray
                                                   arrivalCode:(NSArray *)arrivalCodeArray
                                                 departureTime:(NSArray *)departureTimeArray
                                                andArrivalTime:(NSArray *)arrivalTimeArray;
- (void) customInitialization;
- (void) customAllocation;

@end

@implementation AirwalaFlightTicketsViewController

@synthesize flightTicketsDict = mFlightTicketsDict;
@synthesize flightsListTableView = mFlightsListTableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        [self customAllocation];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back"
//                                                                             style:UIBarButtonItemStyleBordered
//                                                                            target:nil
//                                                                            action:nil];
    UIImage *backButtonImageNormal = [UIImage imageNamed:@"topbar_button_back"];
    UIImage *backButtonImagePressed = [UIImage imageNamed:@"topbar_button_back_pressed"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:backButtonImageNormal forState:UIControlStateNormal];
    [backButton setImage:backButtonImagePressed forState:UIControlStateSelected];

    backButton.frame = CGRectMake(0, 0, backButtonImageNormal.size.width, backButtonImageNormal.size.height);
    
    [backButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = customBarItem;
    
    if(mFlightTicketsDict)
    {
        [self customInitialization];
    }
    
    mFlightsListTableView.rowHeight = 85;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [mMainAirlineName count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"FlightListIdentifier";
    
    AirwalaFlightTicketsCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil)
    {
        cell = [[AirwalaFlightTicketsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.airlineImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"airline_%@",[mMainAirlineCode objectAtIndex:indexPath.row]]];
    cell.airlineNameLabel.text = [mMainAirlineName objectAtIndex:indexPath.row];
    cell.totalPriceLabel.text = [NSString stringWithFormat:@"$%@",[mTotalPrice objectAtIndex:indexPath.row]];
    
    cell = [self organizeFlightTicketsDataInCell:cell
                               withDepartureCode:[mDepartureAirportCodeArray objectAtIndex:indexPath.row]
                                     arrivalCode:[mArrivalAirportCodeArray objectAtIndex:indexPath.row]
                                   departureTime:[mDepartureTimeArray objectAtIndex:indexPath.row]
                                  andArrivalTime:[mArrivalTimeArray objectAtIndex:indexPath.row]];
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    AirwalaFlightTicketDetailViewController *detailViewController = [[AirwalaFlightTicketDetailViewController alloc]initWithNibName:@"AirwalaFlightTicketDetailViewController" bundle:nil];
    detailViewController.title = @"Ticket Details";
    
    detailViewController.airlineImage = [UIImage imageNamed:[NSString stringWithFormat:@"airline_%@",[mMainAirlineCode objectAtIndex:indexPath.row]]];
    detailViewController.airlineNameString = [mMainAirlineName objectAtIndex:indexPath.row];
    
    detailViewController.upwardFlightNumberArray = [[mFlightNumberArray objectAtIndex:indexPath.row] objectAtIndex:0];
    detailViewController.upwardAircraftCodeArray = [[mAircraftCodeArray objectAtIndex:indexPath.row] objectAtIndex:0];

    detailViewController.returnFlightNumberArray = [[mFlightNumberArray objectAtIndex:indexPath.row] objectAtIndex:1];
    detailViewController.returnAircraftCodeArray = [[mAircraftCodeArray objectAtIndex:indexPath.row] objectAtIndex:1];
    
    detailViewController.upwardDepartureCodeArray = [[mDepartureAirportCodeArray objectAtIndex:indexPath.row] objectAtIndex:0];
    detailViewController.upwardArrivalCodeArray = [[mArrivalAirportCodeArray objectAtIndex:indexPath.row] objectAtIndex:0];
    
    detailViewController.returnDepartureCodeArray = [[mDepartureAirportCodeArray objectAtIndex:indexPath.row] objectAtIndex:1];
    detailViewController.returnArrivalCodeArray = [[mArrivalAirportCodeArray objectAtIndex:indexPath.row] objectAtIndex:1];
    
    detailViewController.upwardDepartureTimeArray = [[mDepartureTimeArray objectAtIndex:indexPath.row] objectAtIndex:0];
    detailViewController.upwardArrivalTimeArray = [[mArrivalTimeArray objectAtIndex:indexPath.row] objectAtIndex:0];

    detailViewController.returnDepartureTimeArray = [[mDepartureTimeArray objectAtIndex:indexPath.row] objectAtIndex:1];
    detailViewController.returnArrivalTimeArray = [[mArrivalTimeArray objectAtIndex:indexPath.row] objectAtIndex:1];
    
    detailViewController.adultBasePriceString = [mAdultBasePriceArray objectAtIndex:indexPath.row];
    detailViewController.childBasePriceString = [mChildrenBasePriceArray objectAtIndex:indexPath.row];
    detailViewController.adultTaxString = [mAdultTaxArray objectAtIndex:indexPath.row];
    detailViewController.childTaxString = [mChildrenTaxArray objectAtIndex:indexPath.row];
    detailViewController.totalPriceString = [mTotalPrice objectAtIndex:indexPath.row];
   
    detailViewController.selectedRoutingDetailsDict = [mRoutingDetailsArray objectAtIndex:indexPath.row];
    
//    DLog(@"mAdultBasePriceArray+++++%@",mAdultBasePriceArray);
//    DLog(@"mAdultTaxArray+++++%@",mAdultTaxArray);
//    DLog(@"mChildrenBasePriceArray++++%@",mChildrenBasePriceArray);
//    DLog(@"mChildrenTaxArray+++++%@",mChildrenTaxArray);

    [self.navigationController pushViewController:detailViewController animated:YES];
}

#pragma mark - Action Method

- (void)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Instance Methods

- (AirwalaFlightTicketsCell *)organizeFlightTicketsDataInCell:(AirwalaFlightTicketsCell *)customCell
                                            withDepartureCode:(NSArray *)departureCodeArray
                                                  arrivalCode:(NSArray *)arrivalCodeArray
                                                departureTime:(NSArray *)departureTimeArray
                                               andArrivalTime:(NSArray *)arrivalTimeArray
{
    NSArray *upDepCodeSubArray = [departureCodeArray objectAtIndex:0];
    NSArray *upArrCodeSubArray = [arrivalCodeArray objectAtIndex:0];
    NSArray *upDepTimeSubArray = [departureTimeArray objectAtIndex:0];
    NSArray *upArrTimeSubArray = [arrivalTimeArray objectAtIndex:0];
    
    int upCount = [upArrCodeSubArray count];
    
    customCell.upDepartureCodeLabel.text = [upDepCodeSubArray objectAtIndex:0];
    
    customCell.upDepartureTimeLabel.text = [NSString stringWithFormat:@"(%@)",[[[upDepTimeSubArray objectAtIndex:0]componentsSeparatedByString:@" "]objectAtIndex:1]];
    
    if(upCount > 1)
    {
        customCell.upArrivalCodeLabel.text = [upArrCodeSubArray objectAtIndex:(upCount - 1)];
        customCell.upArrivalTimeLabel.text = [NSString stringWithFormat:@"(%@)",[[[upArrTimeSubArray objectAtIndex:(upCount - 1)]componentsSeparatedByString:@" "]objectAtIndex:1]];
    }
    else
    {
        customCell.upArrivalCodeLabel.text = [upArrCodeSubArray objectAtIndex:0];
        customCell.upArrivalTimeLabel.text = [NSString stringWithFormat:@"(%@)",[[[upArrTimeSubArray objectAtIndex:0]componentsSeparatedByString:@" "]objectAtIndex:1]];
    }
    
    NSArray *downDepCodeSubArray = [departureCodeArray objectAtIndex:1];
    NSArray *downArrCodeSubArray = [arrivalCodeArray objectAtIndex:1];
    NSArray *downDepTimeSubArray = [departureTimeArray objectAtIndex:1];
    NSArray *downArrTimeSubArray = [arrivalTimeArray objectAtIndex:1];
    
    int downCount = [downArrCodeSubArray count];
    
    customCell.downDepartureCodeLabel.text = [downDepCodeSubArray objectAtIndex:0];
    customCell.downDepartureTimeLabel.text = [NSString stringWithFormat:@"(%@)",[[[downDepTimeSubArray objectAtIndex:0]componentsSeparatedByString:@" "] objectAtIndex:1]];
    
    if(downCount > 1)
    {
        customCell.downArrivalCodeLabel.text = [downArrCodeSubArray objectAtIndex:(downCount - 1)];
        customCell.downArrivalTimeLabel.text = [NSString stringWithFormat:@"(%@)",[[[downArrTimeSubArray objectAtIndex:(downCount - 1)] componentsSeparatedByString:@" "] objectAtIndex:1]];
    }
    else
    {
        customCell.downArrivalCodeLabel.text = [downArrCodeSubArray objectAtIndex:0];
        customCell.downArrivalTimeLabel.text = [NSString stringWithFormat:@"(%@)",[[[downArrTimeSubArray objectAtIndex:0] componentsSeparatedByString:@" "] objectAtIndex:1]];
    }
    return customCell;
}

- (void) customInitialization
{
    mRoutingDetailsArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings"];
    mTotalPrice = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.totalPrice"];
    mAdultTaxArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.adultTax"];
    mChildrenTaxArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.childTax"];
    mMainAirlineName = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.mainAirlineName"];
    mMainAirlineCode = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.mainAirlineCode"];
    mAdultBasePriceArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.adultBasePrice"];
    mChildrenBasePriceArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.childBasePrice"];
    mArrivalTimeArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.trips.segments.arrivalTime"];
    mFlightNumberArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.trips.segments.flightNumber"];
    mAircraftCodeArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.trips.segments.aircraftCode"];
    mDepartureTimeArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.trips.segments.departureTime"];
    mArrivalAirportCodeArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.trips.segments.arrivalAirportCode"];
    mDepartureAirportCodeArray = [mFlightTicketsDict valueForKeyPath:@"airTicketListResponse.routings.trips.segments.departureAirportCode"];   
}

- (void) customAllocation
{
    mTotalPrice = [[NSArray alloc]init];
    mAdultTaxArray = [[NSArray alloc]init];
    mMainAirlineName = [[NSArray alloc]init];
    mMainAirlineCode = [[NSArray alloc]init];
    mChildrenTaxArray = [[NSArray alloc]init];
    mArrivalTimeArray = [[NSArray alloc]init];
    mAircraftCodeArray = [[NSArray alloc]init];
    mFlightNumberArray = [[NSArray alloc]init];
    mDepartureTimeArray = [[NSArray alloc]init];
    mAdultBasePriceArray = [[NSArray alloc]init];
    mRoutingDetailsArray = [[NSArray alloc]init];
    mChildrenBasePriceArray = [[NSArray alloc]init];
    mArrivalAirportCodeArray = [[NSArray alloc]init];
    mDepartureAirportCodeArray = [[NSArray alloc]init];
}

@end
