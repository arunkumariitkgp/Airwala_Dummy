//
//  AirwalaTicketResponseViewController.m
//  Airwala
//
//  Created by startupsourcing on 28/09/12.
//
//

#import "AirwalaTicketResponseViewController.h"

@interface AirwalaTicketResponseViewController ()

@end

@implementation AirwalaTicketResponseViewController

@synthesize imageView;
@synthesize responseLabel;
@synthesize responseImage;
@synthesize responseName;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        responseName = [[NSString alloc]init];
        responseImage = [[UIImage alloc]init];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    imageView.image = responseImage;
    responseLabel.text = responseName;
    
    UIImage *backButtonImageNormal = [UIImage imageNamed:@"topbar_button_back"];
    UIImage *backButtonImagePressed = [UIImage imageNamed:@"topbar_button_back_pressed"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:backButtonImageNormal forState:UIControlStateNormal];
    [backButton setImage:backButtonImagePressed forState:UIControlStateSelected];
    
    backButton.frame = CGRectMake(0, 0, backButtonImageNormal.size.width, backButtonImageNormal.size.height);
    
    [backButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = customBarItem;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Selectors

- (void)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
