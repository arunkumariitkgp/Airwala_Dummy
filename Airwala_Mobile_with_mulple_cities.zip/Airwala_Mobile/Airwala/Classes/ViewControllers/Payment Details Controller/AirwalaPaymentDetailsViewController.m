//
//  AirwalaPaymentDetailsViewController.m
//  Airwala
//
//  Created by startupsourcing on 26/09/12.
//
//

#import "UIViewController+MHSemiModal.h"
#import "AirwalaContactDetailsViewController.h"
#import "AirwalaPaymentDetailsViewController.h"

@interface AirwalaPaymentDetailsViewController ()

- (void)customInitialization;
- (void)resigningFirstRespondersIfExist;
- (void)animateTextFieldWithContentOffset:(CGPoint)contentOffset andContentSize:(CGSize)contentSize;
- (BOOL)isAnyTextFieldEmpty;
- (NSArray *)saveAndFormatPaymentData;

@end

@implementation AirwalaPaymentDetailsViewController

@synthesize paymentDetailsTableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        [self customInitialization];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImage *backButtonImageNormal = [UIImage imageNamed:@"topbar_button_back"];
    UIImage *backButtonImagePressed = [UIImage imageNamed:@"topbar_button_back_pressed"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:backButtonImageNormal forState:UIControlStateNormal];
    [backButton setImage:backButtonImagePressed forState:UIControlStateSelected];
    
    backButton.frame = CGRectMake(0, 0, backButtonImageNormal.size.width, backButtonImageNormal.size.height);
    
    [backButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = customBarItem;
    
    UIImage *buttonImageNormal = [UIImage imageNamed:@"topbar_button"];
    UIImage *buttonImagePressed = [UIImage imageNamed:@"topbar_button_pressed"];
    UIButton *bookButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bookButton setBackgroundImage:buttonImageNormal forState:UIControlStateNormal];
    [bookButton setBackgroundImage:buttonImagePressed forState:UIControlStateSelected];
    [bookButton setTitle:@"Next" forState:UIControlStateNormal];
    [bookButton setTitle:@"Next" forState:UIControlStateSelected];
    bookButton.titleLabel.font = [UIFont boldSystemFontOfSize:13.0];
    
    bookButton.frame = CGRectMake(0, 0, buttonImageNormal.size.width, buttonImageNormal.size.height);
    
    [bookButton addTarget:self action:@selector(next:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBar = [[UIBarButtonItem alloc] initWithCustomView:bookButton];
    self.navigationItem.rightBarButtonItem = customBar;
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGesture:)];
    [paymentDetailsTableView addGestureRecognizer:tapGesture];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
//    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"Next"
//                                                                             style:UIBarButtonItemStyleBordered
//                                                                            target:self
//                                                                            action:@selector(next:)];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [mRowNamesArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellId = @"Cell Id";

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellId];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellId];
    }
    cell.textLabel.font = [UIFont systemFontOfSize:15.0];
    cell.textLabel.text = [mRowNamesArray objectAtIndex:indexPath.row];
    cell.textLabel.numberOfLines = 2;
    cell.textLabel.adjustsFontSizeToFitWidth = YES;
    
    AirwalaTextField *textField = [mTextFieldReferenceArray objectAtIndex:indexPath.row];
    textField.tag = indexPath.row + kCreditCardTypeFieldTag;
    textField.delegate = self;
    textField.frame = CGRectMake(cell.frame.origin.x + 50, cell.frame.origin.y + 7, 150, 35);
    textField.backgroundColor = [UIColor clearColor];
    textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    textField.autocorrectionType = UITextAutocorrectionTypeNo;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    textField.placeholder = [mPlaceHoldersArray objectAtIndex:indexPath.row];
    
    if (indexPath.row == 1 || indexPath.row == 3) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
    }
    cell.accessoryView = textField;
    [cell addSubview:[mTextFieldReferenceArray objectAtIndex:indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - TextField Delegates

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    BOOL shouldBeginEditing;
    
    if(textField.tag == kCreditCardTypeFieldTag)
    {
        shouldBeginEditing = NO;
        [self resigningFirstRespondersIfExist];
        
        UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"Select Card Type" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"MasterCard",@"Visa",@"American Express",@"Discover",nil];
        [actionSheet showInView:self.view];
    }
    else if (textField.tag == kExpirationDateFieldTag)
    {
        shouldBeginEditing = NO;
        [self resigningFirstRespondersIfExist];
        
        AirwalaDatePickerViewController *pickerViewController = [[AirwalaDatePickerViewController alloc]initWithNibName:@"AirwalaDatePickerViewController" bundle:[NSBundle mainBundle]];
        pickerViewController.canShowPickerView = YES;
        pickerViewController.delegate = self;
        pickerViewController.selectedTextField = textField;
        [self mh_presentSemiModalViewController:pickerViewController animated:YES];
    }
    else
        shouldBeginEditing = YES;
    
    return shouldBeginEditing;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.tag == kVerificationNumberFieldTag) {
        [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeMake(320.0, 600)];
    }
    else if (textField.tag == kCFirstNameFieldTag) {
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 35.0) andContentSize:CGSizeMake(320.0, 600)];
    }
    else if(textField.tag == kCMiddleNameFieldTag) {
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 80.0) andContentSize:CGSizeMake(320.0, 600)];
    }
    else if(textField.tag == kCLastNameFieldTag) {
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 120.0) andContentSize:CGSizeMake(320.0, 600)];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
    return YES;
}

- (void)tapGesture:(id)sender
{
    for (int index = kCreditCardTypeFieldTag; index <= kCLastNameFieldTag; index ++) {
        AirwalaTextField *tempField = (AirwalaTextField *)[paymentDetailsTableView viewWithTag:index];
        [tempField resignFirstResponder];
    }
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

#pragma mark - UIActionSheet Delegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [UIView beginAnimations:@"animationMoveViewDown" context:nil];
    [paymentDetailsTableView setContentOffset:CGPointZero];
    [UIView commitAnimations];
    
    AirwalaTextField *field = (AirwalaTextField *)[paymentDetailsTableView viewWithTag:kCreditCardTypeFieldTag];
    switch (buttonIndex) {
        case 0:
            field.text = @"M";
            break;
        case 1:
            field.text = @"V";
            break;
        case 2:
            field.text = @"A";
            break;
        case 3:
            field.text = @"D";
            break;
        default:
            break;
    }
}

#pragma mark - Selectors

- (void)next:(id)sender
{
    [self resigningFirstRespondersIfExist];
    if([self isAnyTextFieldEmpty])
    {
        ModalAlert(@"Empty Fields", @"Please give full details", @"OK", nil, nil, nil);
        return;
    }
    NSArray *paymentArray = [self saveAndFormatPaymentData];
    NSArray *paymentKeysArray = [[NSArray alloc]initWithObjects:@"creditCardType", @"creditCardNumber", @"expirationMonth", @"expirationYear", @"cardVerificationNumber", @"firstName", @"middleName", @"lastName", nil];
    NSDictionary *paymentDetails = [[NSDictionary alloc]initWithObjects:paymentArray forKeys:paymentKeysArray];
    NSString *paymentString = [AirwalaUtilities formatDictionaryDetails:paymentDetails];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:paymentString forKey:kPaymentDetails];
    [userDefaults synchronize];
    
    AirwalaContactDetailsViewController *contactDetailsController = [[AirwalaContactDetailsViewController alloc]initWithNibName:@"AirwalaContactDetailsViewController" bundle:nil];
    [self.navigationController pushViewController:contactDetailsController animated:YES];
}

- (void)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - AirwalaDatePickerViewController delegate

- (void)setYearAndMonth:(NSString *)date andTextField:(UITextField *)textField
{
    textField.text = date;
}

#pragma mark - Local Methods

- (void)customInitialization
{
    self.title = @"Payment Details";
    mRowNamesArray = [[NSArray alloc]initWithObjects:@"Credit card type", @"Credit card number", @"Expiration date", @"Card verification number", @"Card holder's first name", @"Middle name", @"Last name", nil];
    mPlaceHoldersArray = [[NSArray alloc]initWithObjects:@"Enter credit card type", @"Enter credit card number", @"Enter expiration date", @"Enter card verification number", @"Enter card holder's first name", @"Enter middle name", @"Enter last name", nil];
    
    mCreditCardTypeField = [[AirwalaTextField alloc]init];
    mCreditCardNumberField = [[AirwalaTextField alloc]init];
    mExpirationDateField = [[AirwalaTextField alloc]init];
    mVerificationNumberField = [[AirwalaTextField alloc]init];
    mFirstNameField = [[AirwalaTextField alloc]init];
    mMiddleNameField = [[AirwalaTextField alloc]init];
    mLastNameField = [[AirwalaTextField alloc]init];
    
    mTextFieldReferenceArray = [[NSArray alloc]initWithObjects:mCreditCardTypeField, mCreditCardNumberField, mExpirationDateField, mVerificationNumberField, mFirstNameField, mMiddleNameField, mLastNameField, nil];
}

- (void)resigningFirstRespondersIfExist
{
    for (int index = kCreditCardTypeFieldTag; index <= kCLastNameFieldTag; index ++) {
        AirwalaTextField *tempField = (AirwalaTextField *)[paymentDetailsTableView viewWithTag:index];
        [tempField resignFirstResponder];
    }
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

- (void)animateTextFieldWithContentOffset:(CGPoint)contentOffset andContentSize:(CGSize)contentSize
{
    [UIView beginAnimations:@"moveUpAndDown" context:nil];
    [paymentDetailsTableView setContentOffset:contentOffset];
    [paymentDetailsTableView setContentSize:contentSize];
    [UIView commitAnimations];
}

- (BOOL)isAnyTextFieldEmpty
{
    for (int index = kCreditCardTypeFieldTag; index <= kCLastNameFieldTag; index ++) {
        AirwalaTextField *tempField = (AirwalaTextField *)[paymentDetailsTableView viewWithTag:index];
        if([AirwalaUtilities isEmptyString:tempField.text] && tempField.tag != kCMiddleNameFieldTag)
            return YES;
    }
    return NO;
}

- (NSArray *)saveAndFormatPaymentData
{
    NSMutableArray *paymentArray = [[NSMutableArray alloc]init];
    for (int index = kCreditCardTypeFieldTag; index <= kCLastNameFieldTag; index ++)
    {
        AirwalaTextField *tempField = (AirwalaTextField *)[paymentDetailsTableView viewWithTag:index];
        if(!tempField.text || [AirwalaUtilities isEmptyString:tempField.text])
            [paymentArray addObject:[NSString stringWithFormat:@""]];
        else
            [paymentArray addObject:tempField.text];
    }
    NSString *str = [paymentArray objectAtIndex:2];
    [paymentArray removeObjectAtIndex:2];
    NSIndexSet *set = [[NSIndexSet alloc]initWithIndexesInRange:NSMakeRange(2, 2)];
    [paymentArray insertObjects:[str componentsSeparatedByString:@", "] atIndexes:set];
    
    NSArray *monthArr = [[NSArray alloc]initWithObjects:@"January",@"February",@"March",@"April",@"May",@"June",@"July",@"August",@"September",@"October",@"November",@"December", nil];
    NSArray *numArray = [[NSArray alloc]initWithObjects:@"01",@"02",@"03",@"04",@"05",@"06",@"07",@"08",@"09",@"10",@"11",@"12", nil];
    NSDictionary *dict = [[NSDictionary alloc]initWithObjects:numArray forKeys:monthArr];
    
    [paymentArray replaceObjectAtIndex:2 withObject:[dict objectForKey:[paymentArray objectAtIndex:2]]];
    return paymentArray;
}

@end
