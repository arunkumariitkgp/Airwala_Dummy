//
//  AirwalaUtilities.m
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AirwalaUtilities.h"

@implementation AirwalaUtilities

id s_AlertViewDelegate;
SEL s_AlertViewSelector;

void ModalAlert(NSString *inTitle, NSString *inMessage, NSString *inActionButton, NSString *inOtherButton, id inDelegate, SEL inSelector)
{
	s_AlertViewDelegate = inDelegate;
	s_AlertViewSelector = inSelector;
    
	UIAlertView *av = [[UIAlertView alloc] initWithTitle:inTitle 
												 message:inMessage 
												delegate:[AirwalaUtilities class] 
									   cancelButtonTitle:inActionButton != nil ? inActionButton : @"OK"
									   otherButtonTitles:inOtherButton, nil];
	[av show];
}

+ (CGSize)getTextSize:(NSString *)aText withFont:(UIFont *)aFont andConstrainedToSize:(CGSize)aSize
{
	return [aText sizeWithFont:aFont constrainedToSize:aSize lineBreakMode:UILineBreakModeWordWrap];
}

+ (BOOL)isEmptyString:(NSString*) string
{
    
    BOOL stringIsEmpty = FALSE;
    
    if ( string == nil || string == (NSString *)[NSNull null] ||(![string respondsToSelector:@selector(isEqualToString:)]) || [string isEqualToString:@"(null)"] || [string isEqualToString:@"<null>"])
        stringIsEmpty = TRUE;
    
    else if ((![string respondsToSelector:@selector(stringByTrimmingCharactersInSet:)]) || [[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length] == 0)
        stringIsEmpty = TRUE;
    
    return stringIsEmpty;
}

+ (NSString *)formatDictionaryDetails:(NSDictionary *)dictinary
{
    NSMutableString *paymentString = [NSMutableString string];
    for (NSString *key in dictinary)
    {
        NSString *value = [dictinary valueForKey:key];
        if([key isEqualToString:@"stop"] || [key isEqualToString:@"duration"])
            [paymentString appendFormat:@"\"%@\":%@,",key,value];
        else
            [paymentString appendFormat:@"\"%@\":\"%@\",",key,value];
    }
    
    if([paymentString length] > 0)
        [paymentString deleteCharactersInRange:NSMakeRange([paymentString length] - 1, 1)];
    return [NSString stringWithFormat:@"{%@}",paymentString];
}

@end
