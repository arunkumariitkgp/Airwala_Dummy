//
//  AirwalaCustomScrollView.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 31/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AirwalaCustomScrollView;

@protocol AirwalaScrollViewProtocol 

- (void)scrollViewTouched;

@end

@interface AirwalaCustomScrollView : UIScrollView
{
    id <AirwalaScrollViewProtocol> mDelegate;
}

@property (nonatomic, assign) id delegate;

@end
