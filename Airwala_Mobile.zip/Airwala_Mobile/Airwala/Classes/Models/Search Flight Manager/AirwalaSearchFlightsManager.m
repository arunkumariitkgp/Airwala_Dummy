//
//  AirwalaSearchFlightsManager.m
//  Airwala
//
//  Created by startupsourcing on 04/09/12.
//
//

#import "AppDelegate.h"
#import "AirwalaWebEngine.h"
#import "AirwalaSearchFlightsManager.h"

@implementation AirwalaSearchFlightsManager

@synthesize roundTripFlightList;

#pragma mark - Singleton Methods

static  AirwalaSearchFlightsManager *sharedInstance = nil;

+ (AirwalaSearchFlightsManager*) sharedInstance
{
    @synchronized(self)
    {
        if (sharedInstance == nil)
		{
			sharedInstance = [[AirwalaSearchFlightsManager alloc] init];
		}
    }
    return sharedInstance;
}

+ (id)allocWithZone:(NSZone *)zone
{
    @synchronized(self)
	{
        if (sharedInstance == nil)
		{
            sharedInstance = [super allocWithZone:zone];
            return sharedInstance;  // assignment and return on first allocation
        }
    }
    return nil; // on subsequent allocation attempts return nil
}

- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (id) init
{
    self = [super init];
    if (self)
    {
        mFlightListDict = [[NSMutableDictionary alloc]init];
    }
    
    return self;
}

#pragma mark - Helper Methods

- (void)setSearchFlightDelegate:(id<AirwalaSearchFlightDelegate>)sender
{
    searchFlightDelegate = sender;
}

-(void)findFlightsListForRoundTripWithSourceAirport:(NSString *)sourceAirport
                                 destinationAirport:(NSString *)destinationAirport
                                      departureDate:(NSString *)depDate
                                         returnDate:(NSString *)retDate
                                     numberOfAdults:(int)adults
                                   numberOfChildren:(int)children
                                       andClassType:(NSString *)classType
{
    self.roundTripFlightList.operationFailedDelegate = self;
    self.roundTripFlightList = [AIRWALA_APP_DELEGATE.webEngine searchAirTicketWithCustomerId:@"I3I6P1"
                                                                           customerSessionId:@"12345"
                                                                            departureAirport:sourceAirport
                                                                          destinationAirport:destinationAirport
                                                                               departureDate:depDate
                                                                                  returnDate:retDate
                                                                               typeOfJourney:@"roundtrip"
                                                                              numberOfAdults:adults
                                                                           numberOfChildrens:children
                                                                                   classType:classType
                                                                         withCompletionBlock:^(id parsedObjects, NSDictionary *userInfo){
                                                                             NSLog(@"Flights List.....%@",parsedObjects);
                                                                             mFlightListDict = [parsedObjects mutableCopy];
                                                                             [self checkingForExistanceOfDelegate];
                                                                         }
                                                                         andErrorBlock:^(NSError *error){
                                                                             NSLog(@"Round Trip Flights List:  ERRORRRRRR");
                                                                         }];
}

- (void)checkingForExistanceOfDelegate
{
    if(searchFlightDelegate && [searchFlightDelegate respondsToSelector:@selector(updateFlightList:)])
    {
        [searchFlightDelegate updateFlightList:mFlightListDict];
    }
}

- (void)operationFailed
{
    if (searchFlightDelegate && [searchFlightDelegate respondsToSelector:@selector(flightListOperationFailed)])
    {
        [searchFlightDelegate flightListOperationFailed];
    }
}

@end
