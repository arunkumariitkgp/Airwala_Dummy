//
//  AirwalaTicketResponseViewController.h
//  Airwala
//
//  Created by startupsourcing on 28/09/12.
//
//

#import <UIKit/UIKit.h>

@interface AirwalaTicketResponseViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIImageView *imageView;
@property (nonatomic, strong) IBOutlet UILabel *responseLabel;
@property (nonatomic, strong) NSString *responseName;
@property (nonatomic, strong) UIImage *responseImage;

@end
