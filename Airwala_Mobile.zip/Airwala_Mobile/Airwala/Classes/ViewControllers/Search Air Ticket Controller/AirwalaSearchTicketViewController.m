//
//  AirwalaSearchTicketViewController.m
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"
#import "AirwalaWebEngine.h"
#import "UIViewController+MHSemiModal.h"
#import "AirwalaAirportListViewController.h"
#import "AirwalaJourneyTypeViewController.h"
#import "AirwalaSearchTicketViewController.h"
#import "AirwalaFlightTicketsViewController.h"


@interface AirwalaSearchTicketViewController ()

- (void)resigningFirstResponders;
- (NSString *)formatSelectedJourneyType:(NSString *)journeyType;
- (void)animateTextFieldWithContentOffset:(CGPoint)contentOffset andContentSize:(CGSize)contentSize;

@end

@implementation AirwalaSearchTicketViewController

#pragma mark - View Outlet Synthesize

@synthesize detailView;
@synthesize typeSegmentControl;
@synthesize firstPageScrollView;
@synthesize thirdPageScrollView;
@synthesize secondPageScrollView;


#pragma mark - Round Trip Synthesize

@synthesize toField;
@synthesize fromField;
@synthesize adultField;
@synthesize classField;
@synthesize childrenField;
@synthesize returnDateField;
@synthesize departureDateField;
@synthesize toActivityIndicator;
@synthesize fromActivityIndicator;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Airwala";
    }
    return self;
}

#pragma mark - View Hierarchy

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    typeSegmentControl.selectedSegmentIndex = 0;
    [typeSegmentControl addTarget:self action:@selector(segmentedControlTapped:) forControlEvents:UIControlEventValueChanged];
    firstPageScrollView.delegate = self;
    secondPageScrollView.delegate = self;
    thirdPageScrollView.delegate = self;
    [fromField addTarget:self action:@selector(searchForText:) forControlEvents:UIControlEventEditingChanged];
    [toField addTarget:self action:@selector(searchForText:) forControlEvents:UIControlEventEditingChanged];
    [[AirwalaAirportListManager sharedInstance]setAirportListDelegate:self];
    [[AirwalaSearchFlightsManager sharedInstance]setSearchFlightDelegate:self];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Segmented Control Method

- (void)segmentedControlTapped:(id)sender
{
    if([sender selectedSegmentIndex] == 0)
    {
        [self resigningFirstResponders];
        [UIView beginAnimations:@"First Page" context:nil];
        detailView.frame = CGRectMake(0, 39, 960, 419);
        [UIView commitAnimations];
    }
    else if([sender selectedSegmentIndex] == 1)
    {
        [self resigningFirstResponders];
        [UIView beginAnimations:@"Second Page" context:nil];
        detailView.frame = CGRectMake(-320, 39, 960, 419);
        [UIView commitAnimations];
    }
    else 
    {
        [self resigningFirstResponders];
        [UIView beginAnimations:@"Third Page" context:nil];
        detailView.frame = CGRectMake(-640, 39, 960, 419);
        [UIView commitAnimations];
    }
}

#pragma mark - TextField Delegate Methods

- (void)searchForText:(UITextField *)textField 
{
    if(textField.text.length == 3)
    {
        if(![AIRWALA_APP_DELEGATE.webEngine isReachable])
        {
            ModalAlert(@"No connection", @"Your device is not connected to the internet! Please connect and try again", @"OK", nil, nil, nil);
            return;
        }
        if(textField == fromField)
            [fromActivityIndicator startAnimating];
        else
            [toActivityIndicator startAnimating];
        [[AirwalaAirportListManager sharedInstance]getAirportsListWithTextField:textField];
    }
}

- (void)displayClassCategoryList:(UITextField *)textField
{
    AirwalaJourneyTypeViewController *journeyTypeController = [[AirwalaJourneyTypeViewController alloc]initWithNibName:@"AirwalaJourneyTypeViewController" bundle:nil];
    journeyTypeController.journeyTypeDelegate = self;
    journeyTypeController.textField = textField;
    [journeyTypeController.classListTableView reloadData];
    [self presentModalViewController:journeyTypeController animated:YES];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    BOOL shouldBeginEditing;
    
    if(textField.tag == kRoundTripTextFieldTag + 2 || textField.tag == kRoundTripTextFieldTag + 3)
    {
        shouldBeginEditing = NO;
        [self resigningFirstResponders];
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 101.0) andContentSize:CGSizeMake(318.0, 590.0)];
        
        AirwalaDatePickerViewController *datePickerViewController = [[AirwalaDatePickerViewController alloc] initWithNibName:@"AirwalaDatePickerViewController" bundle:[NSBundle mainBundle]];
        datePickerViewController.canShowPickerView = NO;
        datePickerViewController.delegate = self;
        datePickerViewController.selectedTextField = textField;
        
        [self mh_presentSemiModalViewController:datePickerViewController animated:YES];  
    }
    else if(textField == classField)
    {
        shouldBeginEditing = NO;
        [self resigningFirstResponders];
        AirwalaJourneyTypeViewController *journeyTypeController = [[AirwalaJourneyTypeViewController alloc]initWithNibName:@"AirwalaJourneyTypeViewController" bundle:nil];
        journeyTypeController.journeyTypeDelegate = self;
        journeyTypeController.textField = textField;
        [journeyTypeController.classListTableView reloadData];
        [self presentModalViewController:journeyTypeController animated:YES];
    }
    else{
        shouldBeginEditing = YES;
    }
    return shouldBeginEditing;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if(textField == adultField || textField == childrenField || textField == classField)
    {
        [self animateTextFieldWithContentOffset:CGPointMake(0.0, 101.0) andContentSize:CGSizeMake(318.0, 590.0)];
    }
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    // may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - Airport List Manager Delegate

- (void)didAirportListDataUpdated:(NSMutableDictionary *)updatedDict andTextField:(UITextField *)textField
{
    if(textField == fromField)
        [fromActivityIndicator stopAnimating];
    else 
        [toActivityIndicator stopAnimating];
    AirwalaAirportListViewController *airportsListController = [[AirwalaAirportListViewController alloc]initWithNibName:@"AirwalaAirportListViewController" bundle:nil];
    airportsListController.selectedAirportDelegate = self;
    airportsListController.textField = textField;
    airportsListController.airportsListArray = [updatedDict valueForKeyPath:@"airportListResponse.airports"];
    [airportsListController.airportsListTableView reloadData];
    [self presentModalViewController:airportsListController animated:YES];
}

- (void)selectedAirportName:(NSString *)airportName andTextField:(UITextField *)textField
{
    [textField setText:airportName];
}

- (void)journeyTypeSelected:(NSString *)journeyType andTextField:(UITextField *)textField
{
    [textField setText:journeyType];
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

- (void)cancelSelectingAirport
{
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

- (void)airportListOperationFailed:(UITextField *)textField
{   
    if(textField == fromField)
        [fromActivityIndicator stopAnimating];
    else
        [toActivityIndicator stopAnimating];
    ModalAlert(@"Operation Failed", @"Please try again", @"OK", nil, nil, nil);
}

#pragma mark - Flights List Manager Delegate

- (void)updateFlightList:(NSMutableDictionary *)flightListDict
{
    [self stopCenterAndNonBlockBusyViewWithTitle];
    if([flightListDict objectForKey:@"hop2WsError"])
    {
        NSArray *arr = [flightListDict valueForKeyPath:@"hop2WsError.errors.message"];
        ModalAlert(@"Wrong Details", [arr objectAtIndex:0], @"OK", nil, nil, nil);
    }
    else
    {
        AirwalaFlightTicketsViewController *flightTicketsController = [[AirwalaFlightTicketsViewController alloc]initWithNibName:@"AirwalaFlightTicketsViewController" bundle:nil];
        flightTicketsController.flightTicketsDict = flightListDict;
        flightTicketsController.title = @"Flight Tickets";
        [self.navigationController pushViewController:flightTicketsController animated:YES];
    }
}

- (void)flightListOperationFailed
{
    [self stopCenterAndNonBlockBusyViewWithTitle];
    ModalAlert(@"Operation Failed", @"Please try again", @"OK", nil, nil, nil);
}

#pragma mark - AirwalaDatePickerViewController delegate

- (void)setDate:(NSDate *)pickerDate andTextField:(UITextField *)textField
{
    if (pickerDate == nil)
    {
        [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
        [UIView commitAnimations];
        return;
    }
    
    NSDateFormatter *displayDateFormatter = [[NSDateFormatter alloc] init];
    [displayDateFormatter setDateFormat:@"MM/dd/yyyy"];
    NSString *displayDateStr = [displayDateFormatter stringFromDate:pickerDate];
    textField.text = displayDateStr;
    
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

#pragma mark - Action Methods

- (IBAction)findFlights:(id)sender
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setInteger:[adultField.text integerValue]
                  forKey:kAdultCount];
    [defaults setInteger:[childrenField.text integerValue]
                  forKey:kChildCount];
    [defaults synchronize];
    
    if(![AIRWALA_APP_DELEGATE.webEngine isReachable])
    {
        ModalAlert(@"No connection", @"Your device is not connected to the internet! Please connect and try again", @"OK", nil, nil, nil);
        return;
    }
    [self startCenterAndNonBlockBusyViewWithTitle:@"Loading..." needUserInteraction:NO];
    //    [[AirwalaSearchFlightsManager sharedInstance]findFlightsListForRoundTripWithSourceAirport:@"hyd" //fromField.text
    //                                                                           destinationAirport:@"blr" //toField.text
    //                                                                                departureDate:@"11/13/2012"//departureDateField.text
    //                                                                                   returnDate:@"12/10/2012"//returnDateField.text
    //                                                                               numberOfAdults:1//[adultField.text intValue]
    //                                                                             numberOfChildren:1//[childrenField.text intValue]
    //                                                                                  andClassType:@"E"];//[self formatSelectedJourneyType:classField.text]];
    
    [[AirwalaSearchFlightsManager sharedInstance]findFlightsListForRoundTripWithSourceAirport:fromField.text
                                                                           destinationAirport:toField.text
                                                                                departureDate:departureDateField.text
                                                                                   returnDate:returnDateField.text
                                                                               numberOfAdults:[adultField.text intValue]
                                                                             numberOfChildren:[childrenField.text intValue]
                                                                                 andClassType:[self formatSelectedJourneyType:classField.text]];
}

#pragma mark - Helper Methods

- (void)resigningFirstResponders
{
    [toField resignFirstResponder];
    [fromField resignFirstResponder];
    [adultField resignFirstResponder];
    [childrenField resignFirstResponder];
    [classField resignFirstResponder];
}

- (NSString *)formatSelectedJourneyType:(NSString *)journeyType
{
    NSArray *arr = [journeyType componentsSeparatedByString:@" - "];
    return [arr objectAtIndex:0];
}

- (void)animateTextFieldWithContentOffset:(CGPoint)contentOffset andContentSize:(CGSize)contentSize
{
    [UIView beginAnimations:@"moveUpOrDown" context:nil];
	firstPageScrollView.contentSize = contentSize;
	firstPageScrollView.contentOffset = contentOffset;
	[UIView commitAnimations];
}

#pragma mark - ScrollView Delegate

- (void)scrollViewTouched
{
    [toField resignFirstResponder];
    [fromField resignFirstResponder];
    [adultField resignFirstResponder];
    [childrenField resignFirstResponder];
    [classField resignFirstResponder];	
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

@end
