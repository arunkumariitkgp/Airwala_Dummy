//
//  AirwalaFlightTicketsViewController.h
//  Airwala
//
//  Created by startupsourcing on 04/09/12.
//
//

#import <UIKit/UIKit.h>

@interface AirwalaFlightTicketsViewController : UIViewController
{
    NSArray *mTotalPrice;
    NSArray *mMainAirlineCode;
    NSArray *mMainAirlineName;
    NSArray *mRoutingDetailsArray;
   
    NSArray *mDepartureTimeArray;
    NSArray *mArrivalTimeArray;
    NSArray *mDepartureAirportCodeArray;
    NSArray *mArrivalAirportCodeArray;
   
    NSArray *mFlightNumberArray;
    NSArray *mAircraftCodeArray;
    NSArray *mAdultBasePriceArray;
    NSArray *mAdultTaxArray;
    NSArray *mChildrenBasePriceArray;
    NSArray *mChildrenTaxArray;
    
    UITableView *mFlightsListTableView;
    NSMutableDictionary *mFlightTicketsDict;
    
}

@property (nonatomic, strong) NSMutableDictionary *flightTicketsDict;
@property (nonatomic, strong) IBOutlet UITableView *flightsListTableView;

@end
