//
//  AirwalaTicketDetailsCell.h
//  Airwala
//
//  Created by startupsourcing on 10/09/12.
//
//

#import <UIKit/UIKit.h>

@interface AirwalaTicketDetailsCell : UITableViewCell

@property (nonatomic, strong) UIImageView *airlineImageView;
@property (nonatomic, strong) UILabel *airlineDetailLabel;
@property (nonatomic, strong) UILabel *airportCodeDetails;

@end
