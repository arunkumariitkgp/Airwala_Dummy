//
//  AirwalaTicketDetailsCell.m
//  Airwala
//
//  Created by startupsourcing on 10/09/12.
//
//

#import "AirwalaTicketDetailsCell.h"

@implementation AirwalaTicketDetailsCell

@synthesize airlineImageView;
@synthesize airlineDetailLabel;
@synthesize airportCodeDetails;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        airlineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 5, 27, 23)];
        
        airlineDetailLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 0, 250, 25)];
        airlineDetailLabel.font = [UIFont systemFontOfSize:14.0];
        airlineDetailLabel.adjustsFontSizeToFitWidth = YES;
        airlineDetailLabel.backgroundColor = [UIColor clearColor];
        
        airportCodeDetails = [[UILabel alloc]initWithFrame:CGRectMake(50, 23, 250, 25)];
        airportCodeDetails.font = [UIFont systemFontOfSize:13.0];
        airportCodeDetails.adjustsFontSizeToFitWidth = YES;
        airportCodeDetails.backgroundColor = [UIColor clearColor];
        
        [self addSubview:airportCodeDetails];
        [self addSubview:airlineImageView];
        [self addSubview:airlineDetailLabel];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
