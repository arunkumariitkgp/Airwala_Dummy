//
//  AirwalaTextField.h
//  Airwala
//
//  Created by startupsourcing on 26/09/12.
//
//

#import <UIKit/UIKit.h>

@interface AirwalaTextField : UITextField

@end
