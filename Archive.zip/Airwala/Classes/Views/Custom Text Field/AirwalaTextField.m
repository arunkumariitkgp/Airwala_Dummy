//
//  AirwalaTextField.m
//  Airwala
//
//  Created by startupsourcing on 26/09/12.
//
//

#import "AirwalaTextField.h"

@implementation AirwalaTextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

- (void) drawPlaceholderInRect:(CGRect)rect
{
    rect.origin.y += 2;
    [[UIColor lightGrayColor] setFill];
    [[self placeholder] drawInRect:rect withFont:[UIFont systemFontOfSize:13]];
}

@end
