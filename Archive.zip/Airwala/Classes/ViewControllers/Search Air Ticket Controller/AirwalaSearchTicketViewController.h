//
//  AirwalaSearchTicketViewController.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AirwalaConstants.h"
#import "AirwalaCustomScrollView.h"
#import "AirwalaAirportListManager.h"
#import "AirwalaSearchFlightsManager.h"
#import "AirwalaDatePickerViewController.h"

@interface AirwalaSearchTicketViewController : UIViewController<AirwalaDatePickerViewControllerDelegate, AirwalaScrollViewProtocol, AirportManagerDelegate, AirwalaSearchFlightDelegate>
{
    NSInteger mSegmentControlIndex;
    
    IBOutlet UIView *detailView;
    IBOutlet UISegmentedControl *typeSegmentControl;
    IBOutlet AirwalaCustomScrollView *thirdPageScrollView;
    IBOutlet AirwalaCustomScrollView *firstPageScrollView;
    IBOutlet AirwalaCustomScrollView *secondPageScrollView;
    
    IBOutlet UITextField *toField;
    IBOutlet UITextField *fromField;
    IBOutlet UITextField *adultField;
    IBOutlet UITextField *classField;
    IBOutlet UITextField *childrenField;
    IBOutlet UITextField *returnDateField;
    IBOutlet UITextField *departureDateField;
    IBOutlet UIActivityIndicatorView *toActivityIndicator;
    IBOutlet UIActivityIndicatorView *fromActivityIndicator;
}

- (IBAction)findFlights:(id)sender;

@end
