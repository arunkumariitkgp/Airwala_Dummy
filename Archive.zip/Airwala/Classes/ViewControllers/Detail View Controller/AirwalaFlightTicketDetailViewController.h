//
//  AirwalaFlightTicketDetailViewController.h
//  Airwala
//
//  Created by startupsourcing on 07/09/12.
//
//

#import <UIKit/UIKit.h>

@interface AirwalaFlightTicketDetailViewController : UIViewController
{
    NSArray *mTableHeaderNamesArray;
    NSArray *mPriceCategoryArray;
    NSArray *mPassengerKeysArray;
    NSArray *mContactKeysArray;
    NSArray *mOnlyAdultsArray;
    
    NSInteger mAdultCount;
    NSInteger mChildrenCount;
    IBOutlet UITableView *ticketDetailsTableView;
}

#pragma mark - General Properties

@property (nonatomic, strong) UIImage *airlineImage;
@property (nonatomic, strong) NSString *airlineNameString;
@property (nonatomic, strong) NSDictionary *selectedRoutingDetailsDict;

#pragma mark - Up Journey Properties

@property (nonatomic, strong) NSArray *upwardFlightNumberArray;
@property (nonatomic, strong) NSArray *upwardAircraftCodeArray;
@property (nonatomic, strong) NSArray *upwardDepartureCodeArray;
@property (nonatomic, strong) NSArray *upwardArrivalCodeArray;
@property (nonatomic, strong) NSArray *upwardDepartureTimeArray;
@property (nonatomic, strong) NSArray *upwardArrivalTimeArray;

#pragma mark - Return Journey Properties

@property (nonatomic, strong) NSArray *returnFlightNumberArray;
@property (nonatomic, strong) NSArray *returnAircraftCodeArray;
@property (nonatomic, strong) NSArray *returnDepartureCodeArray;
@property (nonatomic, strong) NSArray *returnArrivalCodeArray;
@property (nonatomic, strong) NSArray *returnDepartureTimeArray;
@property (nonatomic, strong) NSArray *returnArrivalTimeArray;

#pragma mark - Price Properties

@property (nonatomic, strong) NSString *adultBasePriceString;
@property (nonatomic, strong) NSString *childBasePriceString;
@property (nonatomic, strong) NSString *adultTaxString;
@property (nonatomic, strong) NSString *childTaxString;
@property (nonatomic, strong) NSString *totalPriceString;

@end
