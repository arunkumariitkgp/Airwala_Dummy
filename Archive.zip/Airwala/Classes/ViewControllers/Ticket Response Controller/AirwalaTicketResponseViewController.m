//
//  AirwalaTicketResponseViewController.m
//  Airwala
//
//  Created by startupsourcing on 28/09/12.
//
//

#import "AirwalaTicketResponseViewController.h"

@interface AirwalaTicketResponseViewController ()

- (void)designMainView;

@end

@implementation AirwalaTicketResponseViewController

@synthesize responseImage;
@synthesize secondResponseName;
@synthesize canShowSuccessResponse;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        firstResponseName = [[NSString alloc]init];
        secondResponseName = [[NSString alloc]init];
        thirdResponseName = [[NSString alloc]init];
        responseImage = [[UIImage alloc]init];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImage *backButtonImageNormal = [UIImage imageNamed:@"topbar_button_back"];
    UIImage *backButtonImagePressed = [UIImage imageNamed:@"topbar_button_back_pressed"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:backButtonImageNormal forState:UIControlStateNormal];
    [backButton setImage:backButtonImagePressed forState:UIControlStateSelected];
    
    backButton.frame = CGRectMake(0, 0, backButtonImageNormal.size.width, backButtonImageNormal.size.height);
    
    [backButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = customBarItem;
    
    [self designMainView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Selectors

- (void)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)designMainView
{
    if (self.canShowSuccessResponse)
    {
        imageView.image = responseImage;
        firstResponseLabel.text = @"Thank you for your purchase";
        secondResponseLabel.text = secondResponseName;
        thirdResponseLabel.text = @"Please check your mail to print the ticket";
    }
    else
    {
        imageView.frame = CGRectMake(8,7,304, 400);
        imageView.image = responseImage;
        firstResponseLabel.frame = CGRectZero;
        secondResponseLabel.frame = CGRectZero;
        thirdResponseLabel.frame = CGRectZero;
    }
}
@end
