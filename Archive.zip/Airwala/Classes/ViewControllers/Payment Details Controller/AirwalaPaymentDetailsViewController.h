//
//  AirwalaPaymentDetailsViewController.h
//  Airwala
//
//  Created by startupsourcing on 26/09/12.
//
//

#import <UIKit/UIKit.h>
#import "AirwalaTextField.h"
#import "AirwalaDatePickerViewController.h"

@interface AirwalaPaymentDetailsViewController : UIViewController <UITextFieldDelegate, UIActionSheetDelegate, AirwalaDatePickerViewControllerDelegate>
{
    NSArray *mRowNamesArray;
    NSArray *mPlaceHoldersArray;
    NSArray *mTextFieldReferenceArray;
    
    AirwalaTextField *mCreditCardTypeField;
    AirwalaTextField *mCreditCardNumberField;
    AirwalaTextField *mExpirationDateField;
    AirwalaTextField *mVerificationNumberField;
    AirwalaTextField *mFirstNameField;
    AirwalaTextField *mMiddleNameField;
    AirwalaTextField *mLastNameField;
}

@property (nonatomic, strong) IBOutlet UITableView *paymentDetailsTableView;

@end
