//
//  AirwalaAirportListViewController.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 31/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AirwalaAirportListManager.h"

@interface AirwalaAirportListViewController : UIViewController
{
    NSMutableArray *mAirportsListArray;
    NSObject <AirportManagerDelegate>__unsafe_unretained *selectedAirportDelegate;
}

@property(nonatomic, strong) UITextField *textField;
@property(nonatomic, strong) NSMutableArray *airportsListArray;
@property(nonatomic, strong) IBOutlet UITableView *airportsListTableView;
@property(unsafe_unretained) NSObject<AirportManagerDelegate> *selectedAirportDelegate;

- (IBAction)cancel:(id)sender;
- (NSString *)formatSelectedAirport:(NSString *)selectedAirport;

@end
