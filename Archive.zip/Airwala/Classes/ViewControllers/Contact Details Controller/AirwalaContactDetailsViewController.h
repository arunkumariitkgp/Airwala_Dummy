//
//  AirwalaContactDetailsViewController.h
//  Airwala
//
//  Created by startupsourcing on 27/09/12.
//
//

#import <UIKit/UIKit.h>
#import "AirwalaTextField.h"
#import "AirwalaBookTicketManager.h"
#import "AirwalaDatePickerViewController.h"

@interface AirwalaContactDetailsViewController : UIViewController <UITextFieldDelegate, AirwalaDatePickerViewControllerDelegate, AirwalaBookTicketDelegate>
{
    NSArray *mRowNamesArray;
    NSString *mLastNameString;
    NSString *mFirstNameString;
    NSString *mMiddleNameString;
    NSArray *mPlaceHoldersArray;
    NSArray *mTextFieldReferenceArray;

    AirwalaTextField *mCityField;
    AirwalaTextField *mEmailField;
    AirwalaTextField *mStateField;
    AirwalaTextField *mCountryField;
    AirwalaTextField *mZipCodeField;
    AirwalaTextField *mAddressOneField;
    AirwalaTextField *mAddressTwoField;
    AirwalaTextField *mPhoneNumberField;
}

@property (nonatomic, strong) IBOutlet UITableView *contactDetailsTableView;
@property (nonatomic, strong) NSString *firstNameString;
@property (nonatomic, strong) NSString *middleNameString;
@property (nonatomic, strong) NSString *lastNameString;

@end