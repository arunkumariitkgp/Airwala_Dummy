//
//  AirwalaContactDetailsViewController.m
//  Airwala
//
//  Created by startupsourcing on 27/09/12.
//
//

#import "AppDelegate.h"
#import "AirwalaWebEngine.h"
#import "AirwalaTicketResponseViewController.h"
#import "AirwalaContactDetailsViewController.h"

@interface AirwalaContactDetailsViewController ()

- (void)customInitialization;
- (void)resigningFirstRespondersIfExist;
- (void)animateTextFieldWithContentOffset:(CGPoint)contentOffset andContentSize:(CGSize)contentSize;
- (BOOL)isAnyTextFieldEmpty;
- (NSArray *)saveAndFormatContactData;

@end

@implementation AirwalaContactDetailsViewController

@synthesize contactDetailsTableView;
@synthesize lastNameString = mLastNameString;
@synthesize firstNameString = mFirstNameString;
@synthesize middleNameString = mMiddleNameString;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        [self customInitialization];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImage *backButtonImageNormal = [UIImage imageNamed:@"topbar_button_back"];
    UIImage *backButtonImagePressed = [UIImage imageNamed:@"topbar_button_back_pressed"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:backButtonImageNormal forState:UIControlStateNormal];
    [backButton setImage:backButtonImagePressed forState:UIControlStateSelected];
    
    backButton.frame = CGRectMake(0, 0, backButtonImageNormal.size.width, backButtonImageNormal.size.height);
    
    [backButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = customBarItem;
    
    UIImage *buttonImageNormal = [UIImage imageNamed:@"topbar_button"];
    UIImage *buttonImagePressed = [UIImage imageNamed:@"topbar_button_pressed"];
    UIButton *bookButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bookButton setBackgroundImage:buttonImageNormal forState:UIControlStateNormal];
    [bookButton setBackgroundImage:buttonImagePressed forState:UIControlStateSelected];
    [bookButton setTitle:@"Submit" forState:UIControlStateNormal];
    [bookButton setTitle:@"Submit" forState:UIControlStateSelected];
    bookButton.titleLabel.font = [UIFont boldSystemFontOfSize:13.0];
    
    bookButton.frame = CGRectMake(0, 0, buttonImageNormal.size.width, buttonImageNormal.size.height);
    
    [bookButton addTarget:self action:@selector(submit:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBar = [[UIBarButtonItem alloc] initWithCustomView:bookButton];
    self.navigationItem.rightBarButtonItem = customBar;
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGesture:)];
    [contactDetailsTableView addGestureRecognizer:tapGesture];
    
    [[AirwalaBookTicketManager sharedInstance]setBookTicketDelegate:self];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [mRowNamesArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellId = @"Cell Id";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellId];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellId];
    }
    cell.textLabel.font = [UIFont systemFontOfSize:15.0];
    cell.textLabel.text = [mRowNamesArray objectAtIndex:indexPath.row];
    
    AirwalaTextField *textField = [mTextFieldReferenceArray objectAtIndex:indexPath.row];
    textField.tag = indexPath.row + kAddressOneFieldTag;
    textField.delegate = self;
    textField.frame = CGRectMake(cell.frame.origin.x + 50, cell.frame.origin.y + 7, 150, 35);
    textField.backgroundColor = [UIColor clearColor];
    textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    textField.autocorrectionType = UITextAutocorrectionTypeNo;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    textField.placeholder = [mPlaceHoldersArray objectAtIndex:indexPath.row];
    
    if (indexPath.row == 8 || indexPath.row == 10) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
    }
    if (indexPath.row == 9) {
        textField.keyboardType = UIKeyboardTypeEmailAddress;
    }
    cell.accessoryView = textField;
    [cell addSubview:[mTextFieldReferenceArray objectAtIndex:indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - TextField Delegates

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    switch (textField.tag) {
        case kStateFieldTag:
            [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeMake(320.0, 600)];
            break;
        case kCountryFieldTag:
            [self animateTextFieldWithContentOffset:CGPointMake(0.0, 35.0) andContentSize:CGSizeMake(320.0, 600)];
            break;
        case kZipCodeFieldTag:
            [self animateTextFieldWithContentOffset:CGPointMake(0.0, 80.0) andContentSize:CGSizeMake(320.0, 600)];
            break;
        case kEmailFieldTag:
            [self animateTextFieldWithContentOffset:CGPointMake(0.0, 125.0) andContentSize:CGSizeMake(320.0, 600)];
            break;
        case kPhoneNumberFieldTag:
            [self animateTextFieldWithContentOffset:CGPointMake(0.0, 165.0) andContentSize:CGSizeMake(320.0, 600)];
            break;
        default:
            break;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
    return YES;
}

#pragma mark - Selectors

- (void)submit:(id)sender
{
    [self resigningFirstRespondersIfExist];
    if([self isAnyTextFieldEmpty])
    {
        ModalAlert(@"Empty Fields", @"Please give full details", @"OK", nil, nil, nil);
        return;
    }
    
    NSArray *contactDetails = [self saveAndFormatContactData];
    NSArray *contactKeysArray = [[NSArray alloc]initWithObjects:@"firstName", @"middleName", @"lastName", @"address1", @"address2", @"city", @"state", @"country", @"zipCode", @"emailAddress", @"phoneNumber",nil];
    NSDictionary *contactDict = [[NSDictionary alloc]initWithObjects:contactDetails forKeys:contactKeysArray];
    NSString *contactString = [AirwalaUtilities formatDictionaryDetails:contactDict];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    if(![AIRWALA_APP_DELEGATE.webEngine isReachable])
    {
        ModalAlert(@"No internet", @"Your device is not connected to the internet! Please connect and try again", @"OK", nil, nil, nil);
        return;
    }
    [self startCenterAndNonBlockBusyViewWithTitle:@"Loading..." needUserInteraction:NO];
    [[AirwalaBookTicketManager sharedInstance]bookTicketWithNoOfAdults:[defaults integerForKey:kAdultCount]
                                                          noOfChildren:[defaults integerForKey:kChildCount]
                                                               routing:[defaults objectForKey:kRoutingDetails]
                                                            passengers:[defaults objectForKey:kPassengerDetails]
                                                               payment:[defaults objectForKey:kPaymentDetails]
                                                               contact:contactString
                                                           andClientIP:@"210.90.198.209"];
}

- (void)tapGesture:(id)sender
{
    for (int index = kAddressOneFieldTag; index <= kPhoneNumberFieldTag; index ++) {
        AirwalaTextField *tempField = (AirwalaTextField *)[contactDetailsTableView viewWithTag:index];
        [tempField resignFirstResponder];
    }
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

- (void)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Book Ticket Delegate

- (void)bookTicketResponse:(NSMutableDictionary *)responseDict
{
    [self stopCenterAndNonBlockBusyViewWithTitle];
    if([responseDict objectForKey:@"hop2WsError"])
    {
        NSArray *message = [responseDict valueForKeyPath:@"hop2WsError.errors.message"];
        AirwalaTicketResponseViewController *ticketResponseController = [[AirwalaTicketResponseViewController alloc]initWithNibName:@"AirwalaTicketResponseViewController" bundle:nil];
        ticketResponseController.title = @"Error Response";
        ticketResponseController.canShowSuccessResponse = NO;
        ModalAlert(@"Booking Error", [message objectAtIndex:0], @"OK", nil, nil, nil);
        ticketResponseController.responseImage = [UIImage imageNamed:@"sorry"];
        [self.navigationController pushViewController:ticketResponseController animated:YES];
    }
    else if([responseDict objectForKey:@"airTicketBookingResponse"])
    {
        AirwalaTicketResponseViewController *ticketResponseController = [[AirwalaTicketResponseViewController alloc]initWithNibName:@"AirwalaTicketResponseViewController" bundle:nil];
        ticketResponseController.title = @"Success Response";
        ticketResponseController.canShowSuccessResponse = YES;
        ticketResponseController.secondResponseName = [NSString stringWithFormat:@"Confirmation Code is: %@",[responseDict valueForKeyPath:@"airTicketBookingResponse.recordLocator"]];
        ticketResponseController.responseImage = [UIImage imageNamed:@"congrats"];
        [self.navigationController pushViewController:ticketResponseController animated:YES];
    }
}

- (void)bookTicketOperationFialed
{
    [self stopCenterAndNonBlockBusyViewWithTitle];
    ModalAlert(@"Operation Failed", @"Please try again", @"OK", nil, nil, nil);
}

#pragma mark - Local Methods

- (void)customInitialization
{
    self.title = @"Address Details";
    mRowNamesArray = [[NSArray alloc]initWithObjects:@"Address1", @"Address2", @"City", @"State", @"Country", @"Zip code", @"Email address", @"Phone number",nil];
    mPlaceHoldersArray = [[NSArray alloc]initWithObjects:@"Enter address1", @"Enter address2", @"Enter city", @"Enter state", @"Enter country", @"Enter zip code", @"Enter email address", @"Enter phone number",nil];
    
    mCityField = [[AirwalaTextField alloc]init];
    mEmailField = [[AirwalaTextField alloc]init];
    mStateField = [[AirwalaTextField alloc]init];
    mCountryField = [[AirwalaTextField alloc]init];
    mZipCodeField = [[AirwalaTextField alloc]init];
    mAddressOneField = [[AirwalaTextField alloc]init];
    mAddressTwoField = [[AirwalaTextField alloc]init];
    mPhoneNumberField = [[AirwalaTextField alloc]init];
    
    mTextFieldReferenceArray = [[NSArray alloc]initWithObjects:mAddressOneField, mAddressTwoField, mCityField, mStateField, mCountryField, mZipCodeField, mEmailField, mPhoneNumberField, nil];
}

- (void)resigningFirstRespondersIfExist
{
    for (int index = kAddressOneFieldTag; index <= kPhoneNumberFieldTag; index ++) {
        AirwalaTextField *tempField = (AirwalaTextField *)[contactDetailsTableView viewWithTag:index];
        [tempField resignFirstResponder];
    }
    [self animateTextFieldWithContentOffset:CGPointZero andContentSize:CGSizeZero];
}

- (void)animateTextFieldWithContentOffset:(CGPoint)contentOffset andContentSize:(CGSize)contentSize
{
    [UIView beginAnimations:@"moveUpAndDown" context:nil];
    [contactDetailsTableView setContentOffset:contentOffset];
    [contactDetailsTableView setContentSize:contentSize];
    [UIView commitAnimations];
}

- (BOOL)isAnyTextFieldEmpty
{
    for (int index = kAddressOneFieldTag; index <= kPhoneNumberFieldTag; index ++) {
        AirwalaTextField *tempField = (AirwalaTextField *)[contactDetailsTableView viewWithTag:index];
        if([AirwalaUtilities isEmptyString:tempField.text] && tempField.tag != kAddressTwoFieldTag)
        {
            return YES;
        }
    }
    return NO;
}

- (NSArray *)saveAndFormatContactData
{
    NSMutableArray *contactArray = [[NSMutableArray alloc]initWithObjects:mFirstNameString, mMiddleNameString, mLastNameString, nil];
    for (int index = kAddressOneFieldTag; index <= kPhoneNumberFieldTag; index ++)
    {
        AirwalaTextField *tempField = (AirwalaTextField *)[contactDetailsTableView viewWithTag:index];
        if (!tempField.text || [AirwalaUtilities isEmptyString:tempField.text])
            [contactArray addObject:@""];
        else
            [contactArray addObject:tempField.text];
    }
    return contactArray;
}

@end
