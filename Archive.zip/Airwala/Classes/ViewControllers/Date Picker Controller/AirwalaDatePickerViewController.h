//
//  AirwalaDatePickerViewController.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 31/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AirwalaDatePickerViewControllerDelegate <NSObject>

@optional
- (void)setDate:(NSDate *)pickerdate andTextField:(UITextField *)textField;
- (void)setYearAndMonth:(NSString *)date andTextField:(UITextField *)textField;

@end


@interface AirwalaDatePickerViewController : UIViewController
{    
    NSObject <AirwalaDatePickerViewControllerDelegate>__unsafe_unretained  *mDelegate;
    NSDate *mDefaultDate;
    NSArray *mMonthsArray;
    NSString *mYearString;
    NSString *mMonthString;
}

#pragma mark Accessible Properties

@property (unsafe_unretained) NSObject <AirwalaDatePickerViewControllerDelegate> *delegate;
@property (strong, nonatomic) UITextField *selectedTextField;
@property (strong, nonatomic) NSDate *defaultDate;
@property (assign) BOOL canShowPickerView;

#pragma mark Outlets 

@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;
@property (nonatomic, strong) IBOutlet UIPickerView *pickerView;

#pragma mark IBAction

- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;

@end
