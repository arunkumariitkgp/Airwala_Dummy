//
//  AirwalaConstants.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef Airwala_AirwalaConstants_h
#define Airwala_AirwalaConstants_h

#define AIRWALA_APP_DELEGATE    ((AppDelegate *)[UIApplication sharedApplication].delegate)

#define kRoundTripTextFieldTag 100

#define kFirstNameFieldTag     100
#define kMiddleNameFieldTag    101
#define kLastNameFieldTag      102
#define kTypeFieldTag          103
#define kDOBFieldTag           104
#define kGenderFieldTag        105

#define kCreditCardTypeFieldTag       106
#define kCreditCardNumberFieldTag     107
#define kExpirationDateFieldTag       108
#define kVerificationNumberFieldTag   109
#define kCFirstNameFieldTag           110
#define kCMiddleNameFieldTag          111
#define kCLastNameFieldTag            112

#define kContactFirstNameFieldTag        113
#define kContactMiddleNameFieldTag       114
#define kContactLastNameFieldTag         115
#define kAddressOneFieldTag              116
#define kAddressTwoFieldTag              117
#define kCityFieldTag                    118
#define kStateFieldTag                   119
#define kCountryFieldTag                 120
#define kZipCodeFieldTag                 121
#define kEmailFieldTag                   122
#define kPhoneNumberFieldTag             123


#define kActionSheetGenderTag  1001
#define kActionSheetTypeTag    1002

#define kFemale                 @"F"
#define kMale                   @"M"
#define kAdult                  @"adult"
#define kChild                  @"child"
#define kAdultCount             @"adult_count"
#define kChildCount             @"child_count"
#define kPassengerDetails       @"PassengerDetailsString"
#define kRoutingDetails         @"RoutingDetailsString"
#define kPaymentDetails         @"PaymentDetailsString"

#define kHELVETICA_BOLD			@"Helvetica-Bold"
#define kHELVETICA_REGULAR		@"Helvetica"
#define kHELVETICANEUE_REGULAR	@"HelveticaNeue"
#define kHELVETICANEUE_BOLD		@"HelveticaNeue-Bold"
#define kCHANGAONE_REGULAR      @"ChangaOne"

#define kTripType               @"tripType"
#define kOneWay                 @"oneway"
#define kRoundTrip              @"roundtrip"
#define kMultipleCities         @"multicities"

#endif
