//
//  AirwalaWebEngine.h
//  Airwala
//
//  Created by Startup Sourcing Pvt Ltd on 30/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MKNetworkEngine.h"
#import "MKNetworkKit.h"
#import "AirwalaWebEngineConstants.h"

typedef void (^RequestSuccessBlock) (id parsedObjects, NSDictionary *userInfo);
typedef void (^RequestErrorBlock) (NSError *error);
typedef void (^voidBlock) (void);

@interface AirwalaWebEngine : MKNetworkEngine

- (MKNetworkOperation *)airportListWithCustomerId:(NSString *)customerId 
                                customerSessionId:(NSString *)customerSessionId 
                                     searchString:(NSString *)searchString 
                              withCompletionBlock:(RequestSuccessBlock)successBlock 
                                    andErrorBlock:(RequestErrorBlock)errorBlock;

- (MKNetworkOperation *)roundTripSearchWithCustomerId:(NSString *)customerId
                                    customerSessionId:(NSString *)customerSessionId 
                                     departureAirport:(NSString *)departureAirportName                                   
                                   destinationAirport:(NSString *)destinationAirportName  
                                        departureDate:(NSString *)departureDate                                    
                                           returnDate:(NSString *)returningDate
                                        typeOfJourney:(NSString *)type
                                       numberOfAdults:(int)adults
                                    numberOfChildrens:(int)children
                                            classType:(NSString *)classType
                                  withCompletionBlock:(RequestSuccessBlock)successBlock 
                                        andErrorBlock:(RequestErrorBlock)errorBlock;

- (MKNetworkOperation *)oneWaySearchWithCustomerId:(NSString *)customerId
                                 customerSessionId:(NSString *)customerSessionId
                                  departureAirport:(NSString *)departureAirportName
                                destinationAirport:(NSString *)destinationAirportName
                                     departureDate:(NSString *)departureDate
                                     typeOfJourney:(NSString *)type
                                    numberOfAdults:(int)adults
                                 numberOfChildrens:(int)children
                                         classType:(NSString *)classType
                               withCompletionBlock:(RequestSuccessBlock)successBlock
                                     andErrorBlock:(RequestErrorBlock)errorBlock;

- (MKNetworkOperation *)bookTicketWithCustomerId:(NSString *)customerId
                               customerSessionId:(NSString *)customerSessionId
                                      noOfAdults:(int)adultCount
                                    noOfChildren:(int)childCount
                                         routing:(NSString *)routingDetails
                                      passengers:(NSString *)passengerDetails
                                         payment:(NSString *)paymentDetails
                                         contact:(NSString *)contactDetails
                                     andClientIP:(NSString *)clientIP
                             withCompletionBlock:(RequestSuccessBlock)successBlock
                                   andErrorBlock:(RequestErrorBlock)errorBlock;

@end
